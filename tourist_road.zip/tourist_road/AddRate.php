<?php
 $servername = "localhost"; // Server name
        $username = "root"; // Username
        $password = ""; // Password, left empty here
        $database = "tourist_road"; // Name of the database to connect to

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $database);

        // Check if the connection is successful
        if ($conn->connect_error) {
            // If the connection fails, display the error message and exit the program
            die("Connection failed: " . $conn->connect_error);
        }

if(isset($_POST['email']) and isset($_POST['Rate'])){
	$email=$_POST['email'];
	$trans_num=$_POST['trans_num'];
	$Rate=$_POST['Rate'];
	$Comment=$_POST['comment'];
	$user_id=0;
	$sql = "SELECT * FROM `visitor` WHERE Email='$email'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$user_id=$row['ID'];
		}
	}
	$query = "INSERT INTO `trans_eval` (`id`,`trans_num`, `visitor_id`, `rating`, `comment`, `time_stamp`)
			VALUES (NULL,'$trans_num','$user_id','$Rate','$Comment','1')";
	if(mysqli_query($conn, $query)){
		$status=1;
	}
	else{
		$status=0;
	}
}
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Mar 12 2024 22:15:28 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="duonas-stellar-site.webflow.io" data-wf-page="65c211875b291c1c67993f88"
    data-wf-site="65c211875b291c1c67993f76">

<head>
    <meta charset="utf-8" />
    <title>Ratings</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65c211875b291c1c67993f76/css/duonas-stellar-site.webflow.6191613b5.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=52JpJLCmdX0KbSp8FLysiLzvnFRghfNT1kI7NX9CSxwyaeZ25lFXi5IzJ5iGdHLvZT-mpjUBMns0-Zj4tgTFNQ"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65c211875b291c1c67993f76/65d4c109abda4cb0545de324_lil.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body>
    <div class="nav-menu-three-2-copy">
        <ul role="list" class="nav-menu-block-2 w-list-unstyled">
            <li><a href="#" class="nav-link-3">Home</a></li>
            <li><a href="#" class="nav-link-3">Cities</a><a href="#" class="nav-link-3">Help</a></li>
            <li>
                <div data-hover="false" data-delay="0" class="nav-dropdown-2 w-dropdown">
                    <div class="nav-dropdown-toggle-2 w-dropdown-toggle"></div>
                    <nav class="nav-dropdown-list-2 shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 1</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 2</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 3</a></nav>
                </div>
            </li>
        </ul><img
            src="https://assets-global.website-files.com/65c211875b291c1c67993f76/65c213be89e127fceff033ab_image__1_-removebg-preview.png"
            loading="lazy" width="147" sizes="147px" alt=""
            srcset="https://assets-global.website-files.com/65c211875b291c1c67993f76/65c213be89e127fceff033ab_image__1_-removebg-preview-p-500.png 500w, https://assets-global.website-files.com/65c211875b291c1c67993f76/65c213be89e127fceff033ab_image__1_-removebg-preview.png 516w" />
        <form action="/search" class="w-form"><input class="search-input w-input" maxlength="256" name="query"
                placeholder="Search…" type="search" id="search" required="" /><input type="submit"
                class="search-button w-button" value="Search" /><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                loading="lazy" width="49" alt="" class="image" /><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                loading="lazy" width="49" alt="" class="image" /></form>
    </div>
    <section class="gallery-slider-2">
        <h1 id="w-node-_49c58ca2-08cb-e5ba-dff5-3f8c8a41a549-67993f88" class="heading-3"></h1>
        <p class="paragraph"><strong>Rating</strong></p>
        <div class="container-2">
            <div class="gallery-wrapper-2"><img width="Auto"
                    sizes="(max-width: 479px) 179.1979217529297px, (max-width: 767px) 37vw, (max-width: 991px) 35vw, 23vw"
                    src="https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21be961df2d75ced7888d_%D8%AC%D8%AF%D9%8A%D8%AF.jpg"
                    loading="lazy" alt=""
                    srcset="https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21be961df2d75ced7888d_%D8%AC%D8%AF%D9%8A%D8%AF-p-500.jpg 500w, https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21be961df2d75ced7888d_%D8%AC%D8%AF%D9%8A%D8%AF.jpg 720w"
                    class="gallery-image-3" /><img id="w-node-_52c95b4b-8b0c-878f-d0a3-44400dc7f0f2-67993f88"
                    sizes="(max-width: 479px) 93vw, (max-width: 767px) 45vw, (max-width: 991px) 43vw, 29vw"
                    src="https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21d003287189a1d6c9d70_%D8%AC%D8%AF%D9%8A%D8%AF3.jpg"
                    loading="lazy" alt=""
                    srcset="https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21d003287189a1d6c9d70_%D8%AC%D8%AF%D9%8A%D8%AF3-p-500.jpg 500w, https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21d003287189a1d6c9d70_%D8%AC%D8%AF%D9%8A%D8%AF3-p-800.jpg 800w, https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21d003287189a1d6c9d70_%D8%AC%D8%AF%D9%8A%D8%AF3-p-1080.jpg 1080w, https://assets-global.website-files.com/65c211875b291c1c67993f76/65c21d003287189a1d6c9d70_%D8%AC%D8%AF%D9%8A%D8%AF3.jpg 1128w"
                    class="image-4" />
                <div id="w-node-_7982ddd0-7c87-ec4b-4cc0-47d9ab8c8428-67993f88" class="w-form">
                    <form id="email-form-2" name="email-form-2" method="post" action="AddRate.php">
			  <textarea placeholder="Tourist rating"
                            maxlength="5000" id="comment" name="comment" 
                            class="w-input"></textarea>
			<input type="submit" data-wait="Please wait..."
                            class="submit-button w-button" value="Send" />
                        <div class="fs_starrating-1_component-5">
                            <div class="fs_starrating-1_embed-4 w-embed w-script">
                                <!-- [Finsweet Attributes] Star Rating -->
                                <script>(() => { var t = "https://cdn.jsdelivr.net/npm/@finsweet/attributes-starrating@1/starrating.js", e = document.querySelector(`script[src="${t}"]`); e || (e = document.createElement("script"), e.async = !0, e.src = t, document.head.append(e)); })();</script>
                            </div>
                            <div class="fs_starrating-1_wrapper-6">
                                <div fs-starrating-element="group" class="fs_starrating-1_group-3"><label
                                        class="fs_starrating-1_item-3 w-radio">
                                        <div
                                            class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button-3 w-radio-input">
                                        </div><input id="Star-rating-1-1" type="radio" name="Rate"
                                            data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                            value="1" /><span class="fs_starrating-1_label-3 w-form-label"
                                            for="Star-rating-1-1">Radio</span>
                                        <div fs-starrating-element="star"
                                            class="fs_starrating-1_icon-3 is-active-starrating w-embed"><svg
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24">
                                                <path fill="currentColor"
                                                    d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                            </svg></div>
                                    </label><label class="fs_starrating-1_item-3 w-radio">
                                        <div
                                            class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button-3 w-radio-input">
                                        </div><input id="Star-rating-1-2" type="radio" name="Rate"
                                            data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                            value="2" required /><span class="fs_starrating-1_label-3 w-form-label"
                                            for="Star-rating-1-2">Radio</span>
                                        <div fs-starrating-element="star" class="fs_starrating-1_icon-3 w-embed"><svg
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24">
                                                <path fill="currentColor"
                                                    d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                            </svg></div>
                                    </label><label class="fs_starrating-1_item-3 w-radio">
                                        <div
                                            class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button-3 w-radio-input">
                                        </div><input id="Star-rating-1-3" type="radio" name="Rate"
                                            data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                            value="3" /><span class="fs_starrating-1_label-3 w-form-label"
                                            for="Star-rating-1-3">Radio</span>
                                        <div fs-starrating-element="star" class="fs_starrating-1_icon-3 w-embed"><svg
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24">
                                                <path fill="currentColor"
                                                    d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                            </svg></div>
                                    </label><label class="fs_starrating-1_item-3 w-radio">
                                        <div
                                            class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button-3 w-radio-input">
                                        </div><input id="Star-rating-1-4" type="radio" name="Rate"
                                            data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                            value="4" /><span class="fs_starrating-1_label-3 w-form-label"
                                            for="Star-rating-1-4">Radio</span>
                                        <div fs-starrating-element="star" class="fs_starrating-1_icon-3 w-embed"><svg
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24">
                                                <path fill="currentColor"
                                                    d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                            </svg></div>
                                    </label><label class="fs_starrating-1_item-3 w-radio">
                                        <div
                                            class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button-3 w-radio-input">
                                        </div><input id="Star-rating-1-5" type="radio" name="Rate"
                                            data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                            value="5" /><span class="fs_starrating-1_label-3 w-form-label"
                                            for="Star-rating-1-5">Radio</span>
                                        <div fs-starrating-element="star" class="fs_starrating-1_icon-3 w-embed"><svg
                                                aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                                viewBox="0 0 24 24">
                                                <path fill="currentColor"
                                                    d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                            </svg></div>
                                    </label></div>
                            </div>
                            <div class="fs_starrating-1_message-3">This component</div>
                        </div>
                        <div class="testimonial-info-three"><img
                                src="https://assets-global.website-files.com/65c211875b291c1c67993f76/65d4a5c42ac5eb4a6c2a3c16_%D8%B5%D9%88%D8%B1%D8%A9%20%D9%88%D8%A7%D8%AA%D8%B3%D8%A7%D8%A8%20%D8%A8%D8%AA%D8%A7%D8%B1%D9%8A%D8%AE%201445-08-10%20%D9%81%D9%8A%2010.13.28_1e885944.jpg"
                                loading="lazy" alt="" class="testimonial-image" />
                            <div>
                                <h3 class="testimonial-main-heading">Amal</h3>
					  <input type="email" name="email" value="amal442@gmail.com" required>
					  <?php 
							$connect = mysqli_connect("localhost", "root", "","tourist_road");
							$query = "SELECT trans_num, trans_name FROM `transportation`";
							$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
					    ?>
					  <select class="w-dropdown-toggle" style="width:175px; font-size:13px;" name="trans_num">
						<nav class="w-dropdown-list">
						<option class="w-dropdown-link" value="" disabled>Transportation</option>
						<?php 
							if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) { 
						?>
						<option class="w-dropdown-link" value="<?php echo $row['trans_num']; ?>"><?php echo $row['trans_name']; ?></option>
						<?php } } ?>
						</nav>
					 </select>
					 <?php
						if(isset($status)){
							if($status==1)
								echo "<p style='color:green;'>Rate Added Successfully</p>";
							else
							echo "<p style='color:red;'>Rate Added Failed</p>";
						}
					 ?>
				    </div>
                        </div>
                        <div class="fs_starrating-1_component-5">
                            <div class="fs_starrating-1_embed-4 w-embed w-script">
                                <!-- [Finsweet Attributes] Star Rating -->
                                <script>(() => { var t = "https://cdn.jsdelivr.net/npm/@finsweet/attributes-starrating@1/starrating.js", e = document.querySelector(`script[src="${t}"]`); e || (e = document.createElement("script"), e.async = !0, e.src = t, document.head.append(e)); })();</script>
                            </div>
                           
                    </form>
                    <div class="w-form-done">
                        <div>Thank you! Your submission has been received!</div>
                    </div>
                    <div class="w-form-fail">
                        <div>Oops! Something went wrong while submitting the form.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c211875b291c1c67993f76"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c211875b291c1c67993f76/js/webflow.18e2692d8.js"
        type="text/javascript"></script>
</body>

</html>