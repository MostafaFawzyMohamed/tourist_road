<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$name = $_POST["name"];
	$city = $_POST["city"];
	$cityID=0;
	$query = "SELECT * FROM `city` WHERE city_name='$city'";
	mysqli_query($connect,"SET CHARACTER SET 'utf8'");
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	$count = mysqli_num_rows($result);
	if ($count == 1){
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {			
				$cityID=$row["city_id"];
			}
		}
	}
	$fileName = $_FILES['image']['name'];
	$fileError = $_FILES['image']['error'];
	$fileType = $_FILES['image']['type'];
	$fileSize = $_FILES['image']['size'];
	$data = file_get_contents($_FILES['image']['tmp_name']);
	$file = $_FILES['image']['tmp_name'];
	$fileExt = explode('.', $fileName);
	$fileActualExt = strtolower(end($fileExt));
	$allowed = array('csv','doc','docx','jpg','pdf','png');
	$description = $_POST["description"];
	$link = $_POST["link"];
	$sql="";
	$destination = 'img/Transport/' . $fileName;
		if (in_array($fileActualExt, $allowed)){
		if ($fileError == 0){
			if ($fileSize < 5000000){

				$sql = "INSERT INTO `transportation`(`trans_num`, `trans_name`, `trans_description`, `trans_link`, `tra_img`, `city_id`)
				VALUES  (NULL, '$name', '$description', '$link' ,'$destination' ,'$cityID')";

				if(mysqli_query($connect, $sql)){

					if (move_uploaded_file($file, $destination)) {
						echo "<script>alert('Added Successfully !');</script>";
							echo "<script>window.location='NewTransportation.php'</script>";
					 }
				}
				 
		}
		}
			
		}
		else{
				echo "<script>alert('Invalid Added !');";
				echo "window.location='NewTransportation.php'";
				echo "</script>";
			}			
	
	
	
	
?>