<?php 
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	session_start();
	if(isset($_SESSION["email"])){
		$email=$_SESSION["email"];
	}

	$sql = "SELECT * FROM `visitor` WHERE Email='$email'";
	$result = mysqli_query($connect, $sql);	
	if(isset($_POST["firstname"]) and isset ($_POST["lastname"]) and isset ($_POST["gender"]) and isset ($_POST["email"]) and isset ($_POST["birthdate"]))
	{
		$id=$_POST['id'];
		$firstname= $_POST["firstname"];
		$lastname= $_POST["lastname"];
		$gender= $_POST["gender"];
		$email= $_POST["email"];
		$birthdate= $_POST["birthdate"];
		$query="UPDATE `visitor` SET `first_name`='$firstname',`last_name`='$lastname',`Email`='$email',
		`Birthdate`='$birthdate',`gender`='$gender' WHERE `ID`='" . $id . "'" ;

		if (mysqli_query($connect, $query)) {
			$status=1;
		} else {
			$status=0;
		}
	}
	if(isset($_POST["password"]) and isset ($_POST["confirmpass"])){
		$id=$_POST['id'];
		$password=$_POST["password"];
		$cpassword=$_POST["confirmpass"];
		if($password==$cpassword){
			$query2="UPDATE `visitor` SET `password`='$password' WHERE `ID`='" . $id . "'" ;

			if (mysqli_query($connect, $query2)) {
				$status2=1;
			} else {
				$status2=0;
			}
		}
		else{
			echo "<script>alert('password and confirm password not match!');</script>";
		}
	}
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 11:44:55 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="edit-8193cf.webflow.io" data-wf-page="65c168b02366ea90a1a0c74c"
    data-wf-site="65c168b02366ea90a1a0c745">

<head>
    <meta charset="utf-8" />
    <title>edit</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/css/edit-8193cf.webflow.7f0c794ef.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=IYJ6fHSHMp7Yh8iYvAM2yNICRcFPXy1BDpqueHuSEi5Lzy5Cy7mgTqtn2fl3iRO3jBmpShRON70NCA5YwkJHsw"
        charset="UTF-8"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Droid Serif:400,400italic,700,700italic", "Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link
        href="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65cacdb35738ea91b2e3169d_%D8%B5%D9%88%D8%B1%D9%87%20%D8%A7%D9%84%D8%B4%D8%B9%D8%A7%D8%B1%20(2)%20(2).png"
        rel="shortcut icon" type="image/x-icon" />
    <link
        href="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65cacd68db06007b72c8c9b7_%D8%B5%D9%88%D8%B1%D9%87%20%D8%A7%D9%84%D8%B4%D8%B9%D8%A7%D8%B1%20(2)%20(1).png"
        rel="apple-touch-icon" />
</head>

<body class="body">
    <section class="sec22"><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c168d4513acc4c96746f43_image%20(2)%20(1).png"
            loading="lazy" width="174" id="w-node-_41ae95f7-5f8c-22b3-9af3-edb2e29e8ba1-a1a0c74c" alt=""
            srcset="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c168d4513acc4c96746f43_image%2520(2)%2520(1)-p-500.png 500w, https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c168d4513acc4c96746f43_image%20(2)%20(1).png 561w"
            sizes="173.99998474121094px" class="image-2" />
        <form action="/search" class="search-2 w-form"><input class="search-input-2 w-input" maxlength="256"
                name="query" placeholder="Search…" type="search" id="search" required="" /></form><a
            id="w-node-_13d4d958-bb31-3cf4-d3bd-4bac03ed8b87-a1a0c74c" href="/" aria-current="page"
            class="w-inline-block w--current"><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                loading="lazy" width="36" id="w-node-_41ae95f7-5f8c-22b3-9af3-edb2e29e8ba3-a1a0c74c" alt=""
                class="account-button" /></a><a id="w-node-_41ae95f7-5f8c-22b3-9af3-edb2e29e8b9c-a1a0c74c" href="#"
            class="link"> | Help</a><a id="w-node-_41ae95f7-5f8c-22b3-9af3-edb2e29e8b98-a1a0c74c"
            href="https://home-e45582.webflow.io/" class="link-3">Home |</a><a
            id="w-node-_41ae95f7-5f8c-22b3-9af3-edb2e29e8b9a-a1a0c74c" href="https://home-e45582.webflow.io/"
            class="link-2">Cities</a><a id="w-node-c784788f-8f59-036d-b936-608abdad33a6-a1a0c74c" href="/favlist"
            class="w-inline-block"><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                alt="" width="36" id="w-node-_33b917f3-97ca-5f28-d08c-96398dedc08d-a1a0c74c" class="image-11" /></a>
    </section>
    <main class="sec44"><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c16ecf3a33777ac3cfdae3_11111111111%20(1).png"
            loading="lazy" width="181" alt="" class="image-144" /><a href="UpdateProfile.php?email=<?php echo $email; ?>"
            class="editaccountbutton w-button">Edit account</a><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c16ecf67474f9922240d64_222222222222.png"
            loading="lazy" width="173" alt="" class="image-133" /><a href="fav.php?email=<?php echo $email; ?>"
            class="favoritebutton w-button">Favorite</a><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c16ece1c36dbf932a38a68_33333333333333.png"
            loading="lazy" width="166" alt="" class="image-155" /><a href="https://notifiaction.webflow.io/"
            class="notificationsbutton w-button">Notifications</a></main>
    <h1 class="heading-2">Basic information<br /><br /><br />‍</h1>
    <section>
	<?php 
		if ($result->num_rows > 0) {
		// output data of each row
			while($row = $result->fetch_assoc()) {
	?>
        <div data-ms-form="login" class="form-block w-form">
            <form id="Basic-information" name="email-form" data-name="Email Form" method="post" class="form" action="UpdateProfile.php"
                data-wf-page-id="65c168b02366ea90a1a0c74c" data-wf-element-id="c47823b0-5eba-a7f1-1e34-856b1394df4b">
		    <input type="email" name="email" value="<?php echo $email; ?>" hidden />
		    <input type="number" name="id" value="<?php echo $row['ID']; ?>" hidden />
		    <label for="firstName" class="field-label-5">First Name</label><input class="text-field w-input"
                    maxlength="256" name="firstname" data-name="Name" placeholder="" type="text" id="firstName" value="<?php echo $row['first_name']; ?>" /><label
                    for="lastName" class="field-label-4">Last Name</label><input class="text-field w-input"
                    maxlength="256" name="lastname" data-name="Name 2" placeholder="" type="text" id="lastName" value="<?php echo $row['last_name']; ?>" /><label
                    for="field" class="field-label-3">Gender Type</label><select id="field" name="gender"
                    data-name="Field" required="" class="select-field w-select">
                    <option value="Male">Male</option>
                    <option value="Femele">Female</option>
                </select><label for="email" class="field-label-2">Email Address</label><input class="password w-input"
                    maxlength="256" name="email" data-name="Email" placeholder="" type="email" id="email" value="<?php echo $row['Email']; ?>"
                    required="" /><label for="Day" class="field-label">Birth Date</label><input class="input"
                    type="date" value="<?php echo $row['Birthdate']; ?>" name="birthdate" />
			  <?php
				if(isset($status)){
					if($status==1)
						echo "<span style='color:green;'>Updated Successfully</span>";
					else
						echo "<span style='color:red;'>Updated Failed</span>";
				}
			  ?>
			  <input type="submit" name="submit1" data-wait="Please wait..." class="submit-button w-button"
                    value="Update" /></form>
		
            <div class="w-form-done">
                <div>Thank you! Your submission has been received!</div>
            </div>
            <div class="w-form-fail">
                <div>Oops! Something went wrong while submitting the form.</div>
            </div>
        </div>
        <h1 class="heading-2">Account information<br /><br /><br />‍</h1>
        <div class="w-form">
            <form id="Account-information" name="email-form" method="post" class="form" action="UpdateProfile.php"
                data-wf-page-id="65c168b02366ea90a1a0c74c" data-wf-element-id="23492204-7742-fed3-b462-39d6539ef5d9">
                <p id="w-node-d926e828-bd34-436f-d012-adef3403983f-a1a0c74c" class="paragraph">The password must be at
                    least 8 characters long and contain lowercase and uppercase letters and a symbol, provided that the
                    symbol is one of these symbols only!@#$%^&amp;*+(){}?~`=.&lt;&gt;-</p>
			   <input type="number" name="id" value="<?php echo $row['ID']; ?>" hidden />
			  <input type="email" name="email" value="<?php echo $email; ?>" hidden />
			  <label for="password" type1="password"
                    class="field-label-2">Password</label><input class="password w-input" maxlength="256"
                    name="password" data-name="password" placeholder="" type="password" id="password" pattern=".{8,}" title="Eight or more characters"
                    required="" /><label for="confirm-pass" type1="password" class="field-label-2">Confirm
                    Password</label><input
                    class="text-field w-node-_23492204-7742-fed3-b462-39d6539ef5dc-a1a0c74c w-input" autofocus="true"
                    maxlength="256" name="confirmpass" data-name="confirm pass" placeholder="" type="password"
                    id="confirm-pass" required="" />
			  <?php
				if(isset($status2)){
						if($status2==1)
							echo "<span style='color:green;'>Updated Successfully</span>";
						else
							echo "<span style='color:red;'>Updated Failed</span>";
					}
			?>
			  <input type="submit" name="submit2"  data-wait="Please wait..."
                    class="submit-button w-button" value="Update" />
            </form>
		<?php } } ?>
            <div class="w-form-done">
                <div>Thank you! Your submission has been received!</div>
            </div>
            <div class="w-form-fail">
                <div>Oops! Something went wrong while submitting the form.</div>
            </div>
        </div>
    </section>
    <section></section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c168b02366ea90a1a0c745"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/js/webflow.4e708f6a0.js"
        type="text/javascript"></script>
</body>

</html>