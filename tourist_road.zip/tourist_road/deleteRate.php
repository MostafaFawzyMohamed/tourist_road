<?php
	 $servername = "localhost"; // Server name
        $username = "root"; // Username
        $password = ""; // Password, left empty here
        $database = "tourist_road"; // Name of the database to connect to
        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $database);
        // Check if the connection is successful
        if ($conn->connect_error) {
            // If the connection fails, display the error message and exit the program
            die("Connection failed: " . $conn->connect_error);
        }	
	$trans_num=$_GET["trans_num"];
	
	$sql = "DELETE FROM `trans_eval` WHERE `trans_num`='" . $trans_num . "'";

	if($conn->query($sql)){
		echo "<script>";
		echo "window.location.href = 'ReviewRating.php'";
		echo "</script>";
	}
	else{
		echo "<script>alert('Delete Failed!!');";
		echo "window.location.href = 'ReviewRating.php'";
		echo "</script>";
	}
	mysqli_close($conn);
?>