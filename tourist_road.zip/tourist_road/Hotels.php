<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$query = "SELECT * FROM `hotels`";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect)); 
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 15:55:13 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="accessible-components-site-ba4f94.webflow.io" data-wf-page="65c225cff1bef7f6d11e0aaf"
    data-wf-site="65c225cff1bef7f6d11e0aa0">

<head>
    <meta charset="utf-8" />
    <title>Hotels</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65c225cff1bef7f6d11e0aa0/css/accessible-components-site-ba4f94.webflow.09a77bd23.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=I5PYvxwOU5aEteyYX7QECMZpPdcpLDVyKfBwSb-jAwXmMW_y3t1BeyC9E4SJeoPCphklAZ8qOkBGKhq2F42B3MssVuj7I0geVlkNqiBds9Y"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65c225cff1bef7f6d11e0aa0/65d4cb24fb2e997da72b78f4_lil.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body class="body">
    <div class="nav-menu-three-2-copy">
        <ul role="list" class="nav-menu-block-2 w-list-unstyled">
            <li><a href="#" class="nav-link-3">Home</a></li>
            <li><a href="#" class="nav-link-3">Cities</a><a href="#" class="nav-link-3">Help</a></li>
            <li>
                <div data-hover="false" data-delay="0" class="nav-dropdown-2 w-dropdown">
                    <div class="nav-dropdown-toggle-2 w-dropdown-toggle"></div>
                    <nav class="nav-dropdown-list-2 shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 1</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 2</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 3</a></nav>
                </div>
            </li>
        </ul><img
            src="https://assets-global.website-files.com/65c225cff1bef7f6d11e0aa0/65ca58fc2833831e5f8be42b_image__1_-removebg-preview.png"
            loading="lazy" width="147" sizes="147px" alt=""
            srcset="https://assets-global.website-files.com/65c225cff1bef7f6d11e0aa0/65ca58fc2833831e5f8be42b_image__1_-removebg-preview-p-500.png 500w, https://assets-global.website-files.com/65c225cff1bef7f6d11e0aa0/65ca58fc2833831e5f8be42b_image__1_-removebg-preview.png 516w" />
        <form action="/search" class="w-form"><input class="search-input w-input" maxlength="256" name="query"
                placeholder="Search…" type="search" id="search" required="" /><input type="submit"
                class="search-button w-button" value="Search" /><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                loading="lazy" width="49" alt="" class="image" /><a href="#" class="w-inline-block"><img
                    src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                    loading="lazy" width="49" alt="" class="image" /></a></form>
    </div>
		<section class="section">
			<div class="container"></div>
			
			<?php 
			     if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
			?>
			<div class="features-wrapper-two-copy">
			<ul role="list" class="features-right w-list-unstyled">
			    <li class="features-block-two"><center><a href="HotelDetails.php?hot_num=<?php echo $row['hot_num']; ?>"><img
					src="<?php echo $row['hot_img']; ?>"
					loading="lazy" width="300" sizes="(max-width: 479px) 93vw, 300px" alt=""
					class="image-2" /></a></center></li>
			</ul>
            <div class="form-block w-form">
                <form id="email-form" name="email-form" data-name="Email Form" method="get" class="form-2"
                    data-wf-page-id="65c225cff1bef7f6d11e0aaf"
                    data-wf-element-id="c4d5619a-b75c-1e49-bcca-7adcbbd06d75">
			  	
			  <label for="name" class="field-label-2"><a href="HotelDetails.php?hot_num=<?php echo $row['hot_num']; ?>"><?php echo $row['hot_name'];?></a></label>
                    <p class="paragraph"><?php echo $row['hot_description'];?></p>
                    <div class="fs_starrating-1_component">
                        <div class="fs_starrating-1_wrapper">
                            <div fs-starrating-element="group" class="fs_starrating-1_group"><label
                                    class="fs_starrating-1_item w-radio">
                                    <div
                                        class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button w-radio-input">
                                    </div><input id="Star-rating-1-1" type="radio" name="Star-Rating-1"
                                        data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                        value="1" /><span class="fs_starrating-1_label w-form-label"
                                        for="Star-rating-1-1">Radio</span>
                                    <div fs-starrating-element="star"
                                        class="fs_starrating-1_icon is-active-starrating w-embed"><svg
                                            aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                        </svg></div>
                                </label><label class="fs_starrating-1_item w-radio">
                                    <div
                                        class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button w-radio-input">
                                    </div><input id="Star-rating-1-2" type="radio" name="Star-Rating-1"
                                        data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                        value="2" /><span class="fs_starrating-1_label w-form-label"
                                        for="Star-rating-1-2">Radio</span>
                                    <div fs-starrating-element="star" class="fs_starrating-1_icon w-embed"><svg
                                            aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                        </svg></div>
                                </label><label class="fs_starrating-1_item w-radio">
                                    <div
                                        class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button w-radio-input">
                                    </div><input id="Star-rating-1-3" type="radio" name="Star-Rating-1"
                                        data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                        value="3" /><span class="fs_starrating-1_label w-form-label"
                                        for="Star-rating-1-3">Radio</span>
                                    <div fs-starrating-element="star" class="fs_starrating-1_icon w-embed"><svg
                                            aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                        </svg></div>
                                </label><label class="fs_starrating-1_item w-radio">
                                    <div
                                        class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button w-radio-input">
                                    </div><input id="Star-rating-1-4" type="radio" name="Star-Rating-1"
                                        data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                        value="4" /><span class="fs_starrating-1_label w-form-label"
                                        for="Star-rating-1-4">Radio</span>
                                    <div fs-starrating-element="star" class="fs_starrating-1_icon w-embed"><svg
                                            aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                        </svg></div>
                                </label><label class="fs_starrating-1_item w-radio">
                                    <div
                                        class="w-form-formradioinput w-form-formradioinput--inputType-custom fs_starrating-1_radio-button w-radio-input">
                                    </div><input id="Star-rating-1-5" type="radio" name="Star-Rating-1"
                                        data-name="Star Rating 1" style="opacity:0;position:absolute;z-index:-1"
                                        value="5" /><span class="fs_starrating-1_label w-form-label"
                                        for="Star-rating-1-5">Radio</span>
                                    <div fs-starrating-element="star" class="fs_starrating-1_icon w-embed"><svg
                                            aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279-7.416-3.967-7.417 3.967 1.481-8.279-6.064-5.828 8.332-1.151z" />
                                        </svg></div>
                                </label></div>
                            <h5>Rating: 1.0 </h5>
                        </div>
                    </div>
			  <div class="features-wrapper-two"></div>
			</section>
                </form>
			   
                <div class="w-form-done">
                    <div>Thank you! Your submission has been received!</div>
                </div>
                <div class="w-form-fail">
                    <div>Oops! Something went wrong while submitting the form.</div>
                </div>
            </div>
        </div>
	  <br>
          <?php } } ?>
        
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c225cff1bef7f6d11e0aa0"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c225cff1bef7f6d11e0aa0/js/webflow.3053fd9a1.js"
        type="text/javascript"></script>
</body>

</html>