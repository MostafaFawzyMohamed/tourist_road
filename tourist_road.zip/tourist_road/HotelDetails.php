<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$hot_num=$_GET['hot_num'];
	$query = "SELECT * FROM `hotels` WHERE hot_num='$hot_num'";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect)); 
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 16:21:29 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="duonas-stupendous-site.webflow.io" data-wf-page="65c11fcd43da67dca6e812ee"
    data-wf-site="65c11fcd43da67dca6e812e5">

<head>
    <meta charset="utf-8" />
    <title>Hotel Details</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65c11fcd43da67dca6e812e5/css/duonas-stupendous-site.webflow.51991a852.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=JUAwE4QdfGB1jr0DgvrwEFvShUOxb6Jl1kgjN1XHc4Et0-7uo1UwaQ5hN5ig7ooy092GQtw2xMQvZx4AOIgdWQ"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65c11fcd43da67dca6e812e5/65d4d0f4e74d2c8d4670a4ef_lil.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body>
    <section>
        <div class="nav-menu-three-2-copy">
            <ul role="list" class="nav-menu-block-2 w-list-unstyled">
                <li><a href="#" class="nav-link-8">Home</a></li>
                <li><a href="#" class="nav-link-8">Cities</a><a href="#" class="nav-link-8">Help</a></li>
                <li>
                    <div data-hover="false" data-delay="0" class="nav-dropdown-3 w-dropdown">
                        <div class="nav-dropdown-toggle-3 w-dropdown-toggle"></div>
                        <nav class="nav-dropdown-list-3 shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                                class="nav-dropdown-link-3 w-dropdown-link">Resource Link 1</a><a href="#"
                                class="nav-dropdown-link-3 w-dropdown-link">Resource Link 2</a><a href="#"
                                class="nav-dropdown-link-3 w-dropdown-link">Resource Link 3</a></nav>
                    </div>
                </li>
            </ul>
            <form action="/search" class="w-form"><input class="search-input w-input" maxlength="256" name="query"
                    placeholder="Search…" type="search" id="search" required="" /><img
                    src="https://assets-global.website-files.com/65c0e134dd798acb4fad24f2/65c0e2192a01d6fc97451d57_image__1_-removebg-preview.png"
                    loading="lazy" width="147" alt="" /><input type="submit" class="search-button w-button"
                    value="Search" /><img
                    src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                    loading="lazy" width="49" alt="" class="image" /><img
                    src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                    loading="lazy" width="49" alt="" class="image" /></form>
        </div>
    </section>
    <section class="hero-stack">
        <div class="container">
		<?php 
			     if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
		?>
            <div class="hero-wrapper-two">
                <h1><?php echo $row['hot_name']; ?></h1>
                <p class="margin-bottom-24px">Wadi Wej Vallet Center - Taif, Taif, 21944, Saudi Arabia<br /><?php echo $row['hot_description']; ?></p><img
                    src="<?php echo $row['hot_img']; ?>"
                    loading="lazy"
                    sizes="(max-width: 479px) 94vw, (max-width: 767px) 95vw, (max-width: 991px) 92vw, 750px"
                    srcset="<?php echo $row['hot_img']; ?> 500w"
                    alt="" class="hero-image shadow-two" /><a href="https://maps.app.goo.gl/7Ffgzid6NeYt1aJY8?g_st=ic"
                    id="https-maps.app.goo.gl-7Ffgzid6NeYt1aJY8-g_st-ic" class="link">Go to the location click here</a>
            </div><img
                src="https://assets-global.website-files.com/65c11fcd43da67dca6e812e5/65c20884e1ac9952ddcc8cac_%D9%85%D9%81%D8%B6%D9%84%D9%872.jpg"
                loading="lazy" width="31" sizes="31px" alt=""
                srcset="https://assets-global.website-files.com/65c11fcd43da67dca6e812e5/65c20884e1ac9952ddcc8cac_%D9%85%D9%81%D8%B6%D9%84%D9%872-p-500.jpg 500w, https://assets-global.website-files.com/65c11fcd43da67dca6e812e5/65c20884e1ac9952ddcc8cac_%D9%85%D9%81%D8%B6%D9%84%D9%872.jpg 640w"
                class="image-5" />
		<?php } } ?>
        </div>
    </section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c11fcd43da67dca6e812e5"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c11fcd43da67dca6e812e5/js/webflow.47303a7fd.js"
        type="text/javascript"></script>
</body>

</html>