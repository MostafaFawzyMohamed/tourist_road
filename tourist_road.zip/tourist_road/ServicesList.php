<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 15:57:50 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="mahas-marvelous-site-852c27.webflow.io" data-wf-page="65be485d77b20b5b09f65bab"
    data-wf-site="65be485d77b20b5b09f65ba1">

<head>
    <meta charset="utf-8" />
    <title>Lists</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/css/mahas-marvelous-site-852c27.webflow.16e0c1a74.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=gVqmTx41Rsbzbz94PpPyDaxFgwOqsDDeYzF_ULyYQRpwEHw1qBmFl5N0b8iOsSzne_eZw1_WVpE0g1c7uJ3aSYtAn5jgHwmPGH7YnaZZJao"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65d4cbbae459ac5a9246b561_lil.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body>
    <section>
        <div class="nav-menu-three-2-copy">
            <ul role="list" class="nav-menu-block-4 w-list-unstyled">
                <li><a href="#" class="nav-link-10">Home</a></li>
                <li><a href="#" class="nav-link-10">Cities</a><a href="#" class="nav-link-10">Help</a></li>
                <li>
                    <div data-hover="false" data-delay="0" class="nav-dropdown-4 w-dropdown">
                        <div class="nav-dropdown-toggle-4 w-dropdown-toggle"></div>
                        <nav class="nav-dropdown-list shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 1</a><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 2</a><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 3</a></nav>
                    </div>
                </li>
            </ul><img
                src="https://assets-global.website-files.com/65c0e134dd798acb4fad24f2/65c0e2192a01d6fc97451d57_image__1_-removebg-preview.png"
                loading="lazy" width="147" alt="" />
            <form action="/search" class="w-form"><input class="search-input-9 w-input" maxlength="256" name="query"
                    placeholder="Search…" type="search" id="search" required="" /><input type="submit"
                    class="search-button-8 w-button" value="Search" /><img
                    src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                    loading="lazy" width="49" alt="" class="image-4" /><img
                    src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                    loading="lazy" width="49" alt="" class="image-4" /></form>
        </div>
    </section>
    <section class="pricing-overview">
        <div class="container-3">
            <div class="pricing-grid">
                <div id="w-node-ed53b424-fcac-6f9a-9a86-1ccc2c4ab00c-09f65bab" class="pricing-card-three"><a href="Museums.php"><img
                        src="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3938978d68fe830ad_IMG_1386.jpeg"
                        loading="lazy" sizes="(max-width: 479px) 83vw, (max-width: 767px) 27vw, 200px"
                        srcset="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3938978d68fe830ad_IMG_1386-p-500.jpeg 500w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3938978d68fe830ad_IMG_1386-p-800.jpeg 800w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3938978d68fe830ad_IMG_1386.jpeg 906w"
                        alt="" class="pricing-image" />
                    <h3>Museums &amp; Heritage</h3></a>
                </div>
                <div id="w-node-ed53b424-fcac-6f9a-9a86-1ccc2c4ab016-09f65bab" class="pricing-card-three"><a href="Restaurants.php"><img
                        src="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3803e405540cd6960_IMG_1384.jpeg"
                        loading="lazy" sizes="(max-width: 479px) 83vw, (max-width: 767px) 29vw, 200px"
                        srcset="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3803e405540cd6960_IMG_1384-p-500.jpeg 500w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3803e405540cd6960_IMG_1384-p-800.jpeg 800w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3803e405540cd6960_IMG_1384.jpeg 1060w"
                        alt="" class="pricing-image" />
                    <h3>Restaurants &amp; Cafes</h3></a>
                </div>
                <div id="w-node-ed53b424-fcac-6f9a-9a86-1ccc2c4ab020-09f65bab" class="pricing-card-three"><a href="Hotels.php"><img
                        src="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3fca0ab56c855bd82_IMG_1385.jpeg"
                        loading="lazy" sizes="(max-width: 479px) 83vw, (max-width: 767px) 27vw, 200px"
                        srcset="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3fca0ab56c855bd82_IMG_1385-p-500.jpeg 500w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3fca0ab56c855bd82_IMG_1385-p-800.jpeg 800w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b3fca0ab56c855bd82_IMG_1385.jpeg 960w"
                        alt="" class="pricing-image" />
                    <h3>Resorts &amp; Hotels</h3></a>
                </div>
            </div>
        </div>
        <div class="container-3">
            <div class="pricing-grid">
                <div id="w-node-a9a29752-c732-eea7-7fb1-1df1ac5d7db2-09f65bab" class="pricing-card-three"><a href="Places.php"><img
                        src="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b313e9311ae8ef8c87_IMG_1380.jpeg"
                        loading="lazy" sizes="(max-width: 479px) 83vw, (max-width: 767px) 34vw, 200px"
                        srcset="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b313e9311ae8ef8c87_IMG_1380-p-500.jpeg 500w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b313e9311ae8ef8c87_IMG_1380.jpeg 750w"
                        alt="" class="pricing-image" />
                    <h3>Events, Entertainment<br />Places &amp; Parks</h3></a>
                </div>
                <div id="w-node-a9a29752-c732-eea7-7fb1-1df1ac5d7dbc-09f65bab" class="pricing-card-three"></div>
                <div id="w-node-a9a29752-c732-eea7-7fb1-1df1ac5d7dc6-09f65bab" class="pricing-card-three"><a href="Transportation.php"><img
                        src="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b26bb1c09b8e69490e_IMG_1387.jpeg"
                        loading="lazy" sizes="(max-width: 479px) 83vw, (max-width: 767px) 35vw, 200px"
                        srcset="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b26bb1c09b8e69490e_IMG_1387-p-500.jpeg 500w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b26bb1c09b8e69490e_IMG_1387-p-800.jpeg 800w, https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/65be72b26bb1c09b8e69490e_IMG_1387.jpeg 1024w"
                        alt="" class="pricing-image" />
                    <h3>Transportation</h3></a>
                </div>
            </div>
        </div>
    </section>
    <section class="pricing-overview">
        <div class="container-3"></div>
    </section>
    <section class="pricing-overview">
        <div class="container-3"></div>
    </section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65be485d77b20b5b09f65ba1"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65be485d77b20b5b09f65ba1/js/webflow.47303a7fd.js"
        type="text/javascript"></script>
</body>

</html>