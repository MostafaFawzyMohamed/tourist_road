<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$query = "SELECT * FROM `place`";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect)); 
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 16:02:38 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="mahas-fabulous-site-22eac1.webflow.io" data-wf-page="65bf6b9da4823e356ad91088"
    data-wf-site="65bf6b9da4823e356ad91084">

<head>
    <meta charset="utf-8" />
    <title>Recreational places and farms</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65bf6b9da4823e356ad91084/css/mahas-fabulous-site-22eac1.webflow.f30e26993.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=_9q5MLJrU9kQAdXmM2hXerLADB9e7rsiKLJa2YpFaxpMz56enrVyRa0_NcLUjuTKymlyxDcnaEcN5A-1fXIgSQ"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65bf6b9da4823e356ad91084/65d4cca245d937f1f8772849_lil.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body>
    <section>
        <div class="nav-menu-three-2-copy">
            <ul role="list" class="nav-menu-block-2 w-list-unstyled">
                <li><a href="#" class="nav-link-10">Home</a></li>
                <li><a href="#" class="nav-link-10">Cities</a><a href="#" class="nav-link-10">Help</a></li>
                <li>
                    <div data-hover="false" data-delay="0" class="nav-dropdown-3 w-dropdown">
                        <div class="nav-dropdown-toggle-3 w-dropdown-toggle"></div>
                        <nav class="nav-dropdown-list-3 shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                                class="nav-dropdown-link-3 w-dropdown-link">Resource Link 1</a><a href="#"
                                class="nav-dropdown-link-3 w-dropdown-link">Resource Link 2</a><a href="#"
                                class="nav-dropdown-link-3 w-dropdown-link">Resource Link 3</a></nav>
                    </div>
                </li>
            </ul><img
                src="https://assets-global.website-files.com/65c0e134dd798acb4fad24f2/65c0e2192a01d6fc97451d57_image__1_-removebg-preview.png"
                loading="lazy" width="147" alt="" />
            <form action="/search" class="w-form"><input class="search-input-8 w-input" maxlength="256" name="query"
                    placeholder="Search…" type="search" id="search" required="" /><input type="submit"
                    class="search-button-7 w-button" value="Search" /><img
                    src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                    loading="lazy" width="49" alt="" class="image-3" /><img
                    src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                    loading="lazy" width="49" alt="" class="image-3" /></form>
        </div>
    </section>
    <section class="pricing-overview">
        <div class="container-2">
            <p class="pricing-description"><br /></p>
            <div class="pricing-grid">
		<?php 
			     if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
				?>
                <div id="w-node-c35c767c-aff8-5c77-6ed4-12c42c950f3e-6ad91088" class="pricing-card-three"><a href="PlaceDetails.php?palce_num=<?php echo $row['palce_num']; ?>"><img
                        src="<?php echo $row['place_img']; ?>"
                        loading="lazy" sizes="(max-width: 479px) 83vw, (max-width: 767px) 26vw, 200px"
                        srcset="<?php echo $row['place_img']; ?> 500w"
                        alt="" class="pricing-image" /></a>
                    <a href="PlaceDetails.php?palce_num=<?php echo $row['palce_num']; ?>"><h3><?php echo $row['place_name']; ?></h3></a>
                    <p class="pricing-card-text"></p><a href="#" class="text-link-arrow w-inline-block">
                        <div></div>
                    </a>
                </div>
			<?php } } ?>
            </div>
        </div>
    </section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65bf6b9da4823e356ad91084"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65bf6b9da4823e356ad91084/js/webflow.3053fd9a1.js"
        type="text/javascript"></script>
</body>

</html>