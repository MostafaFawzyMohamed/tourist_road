<?php
// Define database connection information
      $servername = "localhost"; // Server name
      $username = "root"; // Username
      $password = ""; // Password, left empty here
	$database = "tourist_road"; // Name of the database to connect to
      // Create a connection to the database
      $conn = new mysqli($servername, $username, $password, $database);
	// Check if the connection is successful
	if ($conn->connect_error) {
            // If the connection fails, display the error message and exit the program
            die("Connection failed: " . $conn->connect_error);
	}
	$city_id=$_GET["city_id"];
	$query = "DELETE FROM `city` WHERE `city_id`='" . $city_id . "'";
	if(mysqli_query($conn, $query)){
		echo "<script>window.location.href = 'DeleteCity.php'";
		echo "</script>";
	}
	else{
		echo "<script>window.location.href = 'DeleteCity.php'</script>";
	}
	  
?>