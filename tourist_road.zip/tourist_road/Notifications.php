<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	if(isset($_GET['email']))
		$email=$_GET['email'];
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Mon Feb 19 2024 08:55:52 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="notifiaction.webflow.io" data-wf-page="65d301c9f17f19b1fbe5838a"
    data-wf-site="65d301c9f17f19b1fbe58384">

<head>
    <meta charset="utf-8" />
    <title>notifiaction</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/css/notifiaction.webflow.ddc6fd288.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=qv8zR805i7YOWvgMFAT0tPVCeQ2Fsz5P4MdGhur0kuZi-MzmtmRBYNp259bb6DibCyJHzmxV8p8cltCJkvi_wQ"
        charset="UTF-8"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Droid Serif:400,400italic,700,700italic"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link
        href="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d31133c419e8d292ae2d0e_Black%20Elegant%20Modern%20Name%20Initials%20Monogram%20Logo%20(1).jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link
        href="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d31139bbf6425993235563_Black%20Elegant%20Modern%20Name%20Initials%20Monogram%20Logo%20(2).jpg"
        rel="apple-touch-icon" />
</head>

<body class="body">
    <section class="sec223"><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30287d9939b92828fac9d_image%20(2)%20(1).png"
            loading="lazy" width="174" id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d662-fbe5838a" alt=""
            srcset="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30287d9939b92828fac9d_image%2520(2)%2520(1)-p-500.png 500w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30287d9939b92828fac9d_image%20(2)%20(1).png 561w"
            sizes="174px" class="image-33" />
        <form action="/search" class="search-3 w-form"><input class="search2-input-3 w-input" maxlength="256"
                name="query" placeholder="Search…" type="search" id="search" required="" /></form><a href="#"
            id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d666-fbe5838a" class="w-inline-block"></a><a
            id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d668-fbe5838a" href="#" class="link-65"> | Help</a><a
            id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d66a-fbe5838a" href="https://home-e45582.webflow.io/"
            class="link-55">Home |</a><a id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d66c-fbe5838a"
            href="https://home-e45582.webflow.io/" class="_5lonk5">Cities</a><a href="#"
            id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d66e-fbe5838a" class="w-inline-block"><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                alt="" width="36" id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d66f-fbe5838a" class="image-121" /></a><img
            src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
            loading="lazy" width="36" id="w-node-f67c0c28-1dbf-8500-de45-cbf6c8e2d667-fbe5838a" alt=""
            class="account2-button" />
    </section>
    <main class="sec44"><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d304f781b0293563b9f3d0_11111111111%20(1).png"
            loading="lazy" width="210" id="w-node-_9beaef32-c04e-4a8b-e89f-70a3472f6f58-fbe5838a" alt=""
            class="image-144" /><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d304f781b0293563b9f3d2_222222222222.png"
            loading="lazy" width="188" id="w-node-_9beaef32-c04e-4a8b-e89f-70a3472f6f5b-fbe5838a" alt=""
            class="image-133" /><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d304f781b0293563b9f3ce_33333333333333.png"
            loading="lazy" width="180" alt="" class="image-155" /><a href="fav.php?email=<?php echo $email; ?>"
            id="w-node-_9beaef32-c04e-4a8b-e89f-70a3472f6f5c-fbe5838a" class="favoritebutton w-button">Favorite</a><a
            href="Notifications.php?email=<?php echo $email; ?>" class="notificationsbutton w-button">Notifications</a><a
            href="UpdateProfile.php?email=<?php echo $email; ?>" id="w-node-_9beaef32-c04e-4a8b-e89f-70a3472f6f59-fbe5838a"
            class="editaccountbutton w-button">Edit account</a></main>
    <section class="section-12">
        <h1 class="heading-6">Notifications</h1>
    </section>
    <section class="section-11">
        <h1 class="heading-8">You have received a comment</h1>
    </section>
    <section class="section-10">
        <h1 class="heading-4">3 dots cafe</h1><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30c2b0b1cfac67a6f9b06_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20110531.png"
            loading="lazy" width="143" alt="" class="image-160" /><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1.png"
            loading="lazy" width="63" sizes="63px" alt=""
            srcset="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1-p-500.png 500w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1-p-800.png 800w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1.png 840w"
            class="image-159" /><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404.png"
            loading="lazy" width="476" sizes="(max-width: 479px) 100vw, 476px" alt=""
            srcset="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404-p-500.png 500w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404-p-800.png 800w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404.png 893w"
            class="image-161" /><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1.png"
            loading="lazy" width="62" sizes="62px" alt=""
            srcset="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1-p-500.png 500w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1-p-800.png 800w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30b138d853d5b1e3d3dab_male-user-filled-icon-man-icon-115533970576b3erfsss1.png 840w"
            class="image-162" /><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404.png"
            loading="lazy" width="532" sizes="(max-width: 767px) 100vw, 532px" alt=""
            srcset="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404-p-500.png 500w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404-p-800.png 800w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d30e0f88fdaa6c6ea464bf_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20111404.png 893w"
            class="image-163" /><img
            src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d309a63dcf2f0455f5650b_IMG-20220815-WA0003.jpg"
            loading="lazy" width="300" sizes="(max-width: 479px) 100vw, 300px" alt=""
            srcset="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d309a63dcf2f0455f5650b_IMG-20220815-WA0003-p-500.jpg 500w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d309a63dcf2f0455f5650b_IMG-20220815-WA0003-p-800.jpg 800w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d309a63dcf2f0455f5650b_IMG-20220815-WA0003-p-1080.jpg 1080w, https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/65d309a63dcf2f0455f5650b_IMG-20220815-WA0003.jpg 1360w"
            class="image-158" />
    </section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65d301c9f17f19b1fbe58384"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65d301c9f17f19b1fbe58384/js/webflow.99dcd72d4.js"
        type="text/javascript"></script>
</body>

</html>