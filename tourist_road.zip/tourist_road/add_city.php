<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$city_name = $_POST["name"];
	$query = "SELECT * FROM `city`";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	$fileName = $_FILES['image']['name'];
	$fileError = $_FILES['image']['error'];
	$fileType = $_FILES['image']['type'];
	$fileSize = $_FILES['image']['size'];
	$data = file_get_contents($_FILES['image']['tmp_name']);
	$file = $_FILES['image']['tmp_name'];
	$fileExt = explode('.', $fileName);
	$fileActualExt = strtolower(end($fileExt));
	$allowed = array('csv','doc','docx','jpg','pdf','png');
	$sql="";
	$description=$_POST['description'];
	$destination = 'img/City/' . $fileName;
		if (in_array($fileActualExt, $allowed)){
		if ($fileError == 0){
			if ($fileSize < 5000000){

				$sql = "INSERT INTO `city`(`city_id`, `city_name`,`city_description`, `city_img`)
				VALUES  (NULL, '$city_name', '$description' ,'$destination')";

				if(mysqli_query($connect, $sql)){

					if (move_uploaded_file($file, $destination)) {
						echo "<script>alert('Added Successfully !');</script>";
							echo "<script>window.location='NewCity.html'</script>";
					 }
				}
				 
		}
		}
			
		}
		else{
				echo "<script>alert('Invalid Added !');";
				echo "window.location='NewCity.html'";
				echo "</script>";
			}			
	
	
	
	
?>