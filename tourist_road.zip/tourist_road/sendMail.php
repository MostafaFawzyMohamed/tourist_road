<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);
$email = $_POST['Email'];
$randomNumber = "1357984620"; 
    $otpNumber = ""; 
    for ($y = 1; $y <= 6; $y++) { 
        $otpNumber .= substr($randomNumber, (rand()%(strlen($randomNumber))), 1); 
    }   

try {
	$mail->SMTPDebug = 2;									 
	$mail->isSMTP();										 
	$mail->Host	 = 'smtp-relay.brevo.com';				 
	$mail->SMTPAuth = true;							 
	$mail->Username = 'touristroad10@gmail.com';				 
	$mail->Password = 'Jydcwk6hzYIKpn1f';					 
	$mail->SMTPSecure = 'tls';							 
	$mail->Port	 = 587; 

	$mail->setFrom('touristroad10@gmail.com', 'Tourist Road');		 
	$mail->addAddress($email);
	
	$mail->isHTML(true);								 
	$mail->Subject = 'Subject';
	$mail->Body = 'OTP For (TouristRoad Account) is : <b>'.$otpNumber.'</b> ';
	$mail->AltBody = 'Body in plain text for non-HTML mail clients';
	$mail->SMTPOptions = array(
                  'ssl' => array(
                      'verify_peer' => false,
                      'verify_peer_name' => false,
                      'allow_self_signed' => true
                  )
              );
	$mail->send();
	echo "Mail has been sent successfully!";
	session_start();
	$_SESSION["email"] = $email;
	$_SESSION["otpNumber"] = $otpNumber;
	echo "<script>alert('otp number is sent to Mail successfully!');";
	echo "window.location.href = 'checkOtpNumber.php'</script>";
} catch (Exception $e) {
	echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>
