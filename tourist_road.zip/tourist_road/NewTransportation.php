<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Mar 05 2024 21:12:57 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="page2-bec494.webflow.io" data-wf-page="65bfd8fa5894473eed8a3419"
    data-wf-site="65bfd8fa5894473eed8a340c">

<head>
    <meta charset="utf-8" />
    <title>Add Transportation</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/css/page2-bec494.webflow.ba200ebd5.css"
        rel="stylesheet" type="text/css" />
	
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=J9IE3Avubh0vM1bwfWkAJ4XOLsKnAlQyyT1cJYMaWQsB6tLT7duZQ3Z5uW2qn2VBavwo9YUILnEn46ArdGL_RQ"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/65d351f905e32d9cf70c8b45_logo.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body class="body">
    <section class="section-4">
        <div class="nav-menu-three-3"><a href="https://222-15f145.webflow.io/pg4" class="link">Cities</a><a
                href="https://admin-ratings.webflow.io/untitled" class="link-4">Raitings</a>
            <ul role="list" class="nav-menu-block w-list-unstyled">
                <li>
                    <div data-hover="false" data-delay="0" class="nav-dropdown w-dropdown">
                        <div class="nav-dropdown-toggle w-dropdown-toggle"></div>
                        <nav class="nav-dropdown-list shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 1</a><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 2</a><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 3</a></nav>
                    </div>
                </li>
            </ul><img
                src="https://assets-global.website-files.com/65b9686e49248c9a63b1662b/65be638e19d6a084e4867eed_image__7_-removebg-preview.png"
                loading="lazy" width="55" height="50" alt="" class="image-2" /><a href="https://home-e45582.webflow.io/"
                class="button-7 w-button">log out</a>
        </div>
    </section>
    <center><h3 class="field-label-2" style="margin-top:-50px; margin-left:275px;">Add Transportation</h3></center>
    <form id="email-form-4" name="email-form-4" method="post" action="add_transportaion.php" enctype="multipart/form-data">
    <div class="w-form" >
        <div id="email-form" name="email-form" style="margin-top:50px;">  
	 
		<input
                class="text-field w-input" maxlength="256" name="name" placeholder="" type="text"
                id="name" /><label for="name"
                class="field-label-2">Name :</label>
		<label for="description" class="field-label-3">The description:</label>
		<textarea id="description" name="description" maxlength="5000"  placeholder="Example Text"
                class="textarea w-input"></textarea><img width="150" sizes="150px" alt=""
                src="https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/65c0e945fc77c50314a4f618_image-removebg-preview.png"
                loading="lazy"
                srcset="https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/65c0e945fc77c50314a4f618_image-removebg-preview-p-500.png 500w, https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/65c0e945fc77c50314a4f618_image-removebg-preview.png 510w"
                class="image-5" />
            <div class="text-block-5">Photo :</div><label for="" class="field-label-4">Photo :</label><img
                src="https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/65c0e945fc77c50314a4f618_image-removebg-preview.png"
                loading="lazy" width="100" sizes="100px" alt=""
                srcset="https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/65c0e945fc77c50314a4f618_image-removebg-preview-p-500.png 500w, https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/65c0e945fc77c50314a4f618_image-removebg-preview.png 510w"
                class="image-7" />
		    <a href="ViewTransportation.php"><input type="button" class="button-2 w-button" name="cancel" value="Cancel"></a>
		    <input type="submit" class="submit-button w-button" name="submit" value="Add">
		    <input type="file" class="button-3 w-button" name="image" required/>

		    <label for=""
                class="field-label-5">city :</label>
        <div class="w-form-done">
            <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
            <div>Oops! Something went wrong while submitting the form.</div>
        </div>
    </div>
    <?php 
		$connect = mysqli_connect("localhost", "root", "","tourist_road");
		$query = "SELECT * FROM `city`";
		$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
    ?>
    <div data-hover="false" data-delay="0" class="dropdown w-dropdown">
		<select class="w-dropdown-toggle" name="city">
		<nav class="w-dropdown-list">
		<option class="w-dropdown-link" value="">City</option>
		<?php 
			if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) { 
		?>
		<option class="w-dropdown-link" value="<?php echo $row['city_name']; ?>"><?php echo $row['city_name']; ?></option>
		<?php } } ?>
		</nav>
		</select>
	</div>
	<input
                class="text-field w-input" style="margin-top:375px;" maxlength="256" name="link" placeholder="" type="text"
                id="link" />
		    <label for=""
                class="field-label-5" style="margin-top:150px;">link :</label>
    </div>
    </form>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65bfd8fa5894473eed8a340c"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65bfd8fa5894473eed8a340c/js/webflow.af2b765de.js"
        type="text/javascript"></script>
</body>

</html>