<?php
// Define database connection information
        $servername = "localhost"; // Server name
        $username = "root"; // Username
        $password = ""; // Password, left empty here
        $database = "tourist_road"; // Name of the database to connect to

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $database);

        // Check if the connection is successful
        if ($conn->connect_error) {
            // If the connection fails, display the error message and exit the program
            die("Connection failed: " . $conn->connect_error);
        }

if (isset($_POST['email']) and isset($_POST['pass']))
{
	$email = $_POST['email'];
	$password = $_POST['pass'];
	$sql = "SELECT * FROM `administrator` WHERE Admin_email='$email' and Admin_pass='$password'";
	$result = mysqli_query($conn, $sql);
	$find = mysqli_num_rows($result);
	if ($find >= 1)
	{
		echo "<script>window.location.href = 'citySettings.html'</script>";
	}
	else{
		echo "<script>window.location.href = 'Admin_Login.php'</script>";
	}
}
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 07:51:34 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="login-6ce45c.webflow.io" data-wf-page="65bfdb3552255888485df402"
    data-wf-site="65bfdb3552255888485df3ff">

<head>
    <meta charset="utf-8" />
    <title>login</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65bfdb3552255888485df3ff/css/login-6ce45c.webflow.cc60b307b.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=AQ6_tQuhgcIxSR8DdNCGW6XIUJcnDuERgJvmVdar2DSZs0mBOdpOrI9ty-9g8Mc8wqjp714kqxEx1vICIO4S9A"
        charset="UTF-8"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Merriweather:300,300italic,400,400italic,700,700italic,900,900italic", "PT Sans:400,400italic,700,700italic", "PT Serif:400,400italic,700,700italic"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65bfdb3552255888485df3ff/65cb0770245275a666839326_ee.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/65bfdb3552255888485df3ff/65cb077597b68c8f21163c98_eee.jpg"
        rel="apple-touch-icon" />
</head>

<body class="body-2">
    <div class="nav-menu-three-2-copy">
        <ul role="list" class="nav-menu-block w-list-unstyled">
            <li><a href="#" class="nav-link-3">Home</a></li>
            <li><a href="#" class="nav-link-3">Cities</a><a href="#" class="nav-link-3">Help</a></li>
            <li>
                <div data-hover="false" data-delay="0" class="nav-dropdown-2 w-dropdown">
                    <div class="nav-dropdown-toggle-2 w-dropdown-toggle"></div>
                    <nav class="nav-dropdown-list-2 shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 1</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 2</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 3</a></nav>
                </div>
            </li>
        </ul><img
            src="https://assets-global.website-files.com/65bfdb3552255888485df3ff/65bfdc22be8065401ac579d0_image.png"
            loading="lazy" width="134" alt="" />
        <form action="/search" class="search w-form"><input class="search-input-2 w-input" maxlength="256" name="query"
                placeholder="Search…" type="search" id="search" required="" /><input type="submit"
                class="search-button-2 w-button" value="Search" /></form>
    </div>
    <h3 class="heading">Sign in to Tourist Road (For Administrator)</h3>
    <div class="form-block-2 w-form">
        <form id="email-form" name="email-form" data-name="Email Form" method="post" class="form-5" action="Admin_Login.php"
            data-wf-page-id="65bfdb3552255888485df402" data-wf-element-id="0c400cbe-eab9-309a-3c7b-952fd989cdd7"><label
                for="Email-3">Email Address</label><input class="text-field-6 w-input" maxlength="256" name="email"
                placeholder="e.g. tr@gmail.com" type="email" id="email" required="" /><label
                for="Password" class="field-label-2">Password</label><input class="text-field-7 w-input" maxlength="256"
                name="pass" placeholder="* * * * * * * * * * *" type="password"
                id="Password-3" required/><a href="/forgot-password" target="_blank" class="link-2">Forgot
                Password?</a><input type="submit" data-wait="Please wait..." class="submit-button-4 w-button"
                value="SIGN IN" /></form>
        <div class="w-form-done">
            <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
            <div>Oops! Something went wrong while submitting the form.</div>
        </div>
    </div>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65bfdb3552255888485df3ff"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65bfdb3552255888485df3ff/js/webflow.3053fd9a1.js"
        type="text/javascript"></script>
</body>

</html>