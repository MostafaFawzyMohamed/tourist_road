<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Fri Mar 01 2024 18:18:09 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="toursit.webflow.io" data-wf-page="65bfdd493684ac48c374a78f"
    data-wf-site="65bfa2e25894473eed6c3a62">

<head>
    <meta charset="utf-8" />
    <title>City Settings</title>
    <meta content="Transportation options" property="og:title" />
    <meta content="Transportation options" property="twitter:title" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="123.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=cfzdAy4GXsca-DDiF2-SkVzI2qNmMF2vH8Oz6wjOeaQvbpKQr-ZUynaONUpCPgWYrn_igOv9b-rbwA0d4NnjtQ"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/65d3525fd84619a695746188_logo.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body class="body-2">
    <section class="section">
        <!-- Navigation Menu -->
        <div class="nav-menu-three">
            <a href="https://222-15f145.webflow.io/pg4" class="link">Cities</a>
            <a href="https://admin-ratings.webflow.io/untitled" class="link-2">Ratings</a>
            <ul role="list" class="nav-menu-block w-list-unstyled">
                <li>
                    <div data-hover="false" data-delay="0" class="nav-dropdown w-dropdown">
                        <div class="nav-dropdown-toggle w-dropdown-toggle"></div>
                        <nav class="nav-dropdown-list shadow-three mobile-shadow-hide w-dropdown-list">
                            <a href="#" class="nav-dropdown-link w-dropdown-link">Resource Link 1</a>
                            <a href="#" class="nav-dropdown-link w-dropdown-link">Resource Link 2</a>
                            <a href="#" class="nav-dropdown-link w-dropdown-link">Resource Link 3</a>
                        </nav>
                    </div>
                </li>
            </ul>
            <img src="https://assets-global.website-files.com/65b9686e49248c9a63b1662b/65be638e19d6a084e4867eed_image__7_-removebg-preview.png"
                loading="lazy" width="55" height="50" alt="" class="image-2" />
            <a href="https://home-e45582.webflow.io/" class="button w-button">Log out</a>
        </div>
    </section>

    <!-- Display Transportation Options -->
    
        <?php
        // Define database connection information
        $servername = "localhost"; // Server name
        $username = "root"; // Username
        $password = ""; // Password, left empty here
        $database = "tourist_road"; // Name of the database to connect to

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $database);

        // Check if the connection is successful
        if ($conn->connect_error) {
            // If the connection fails, display the error message and exit the program
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to fetch transportation options from the database
        $sql = "SELECT * FROM city ";
$result = $conn->query($sql);

// Check if there are results
if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<div class='text-block-7'><strong class='bold-text-6'>" . $row['city_name'] . "</strong></div>";
        echo "<div>";
	  echo "<a href='deleteC.php?city_id=".$row['city_id']."' class='button-17 w-button'>Delete</a>";
        echo "<a href='editC.php?city_id=".$row['city_id']."' class='button-18 w-button'>Edit</a>";
        echo "</div>";
        echo "</div>";
    
    }
} else {
    echo "0 results";
}


        // Close database connection
        $conn->close();
        ?>

    <!-- Additional HTML Elements -->
    <div class="text-block-6" style="font-size:30px; margin-left:175px;">City</div>
    <a href="NewCity.html" class="button-4 w-button">Add City</a>
    <a href="Admin.php" class="button-16 w-button">Back</a>

    <!-- JavaScript Files -->
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65bfa2e25894473eed6c3a62"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/js/webflow.ee0c59c5d.js"
        type="text/javascript"></script>
</body>

</html>
