<?php 
$connect = mysqli_connect("localhost", "root", "","tourist_road");
$id=$_GET['transport_id'];
$query = "SELECT * FROM `transportation` WHERE trans_num='$id'";
$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
			
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Mar 12 2024 21:47:52 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="toursit.webflow.io" data-wf-page="65bfa2e25894473eed6c3a68"
    data-wf-site="65bfa2e25894473eed6c3a62">

<head>
    <meta charset="utf-8" />
    <title>Edit Transportation</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/css/toursit.webflow.95cac0cfd.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=3vfKo2eU4FHkbI4W8IAnssTD7qae_lTqZTV9RuNRdBLONWwGNNPB6-f4QjpwijVQ"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/65d3525fd84619a695746188_logo.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body class="body">
    <section class="section">
        <div class="nav-menu-three"><a href="https://222-15f145.webflow.io/pg4" class="link">Cities</a><a
                href="https://admin-ratings.webflow.io/untitled" class="link-2">Raitings</a>
            <ul role="list" class="nav-menu-block w-list-unstyled">
                <li>
                    <div data-hover="false" data-delay="0" class="nav-dropdown w-dropdown">
                        <div class="nav-dropdown-toggle w-dropdown-toggle"></div>
                        <nav class="nav-dropdown-list shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 1</a><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 2</a><a href="#"
                                class="nav-dropdown-link w-dropdown-link">Resource Link 3</a></nav>
                    </div>
                </li>
            </ul><img
                src="https://assets-global.website-files.com/65b9686e49248c9a63b1662b/65be638e19d6a084e4867eed_image__7_-removebg-preview.png"
                loading="lazy" width="55" height="50" alt="" class="image-2" /><a href="https://home-e45582.webflow.io/"
                class="button w-button">log out</a>
        </div>
    </section><img
        src="https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/65bfcb8f7e4ae2e81db4070d_image-removebg-preview.png"
        loading="lazy" width="150" sizes="150px" alt=""
        srcset="https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/65bfcb8f7e4ae2e81db4070d_image-removebg-preview-p-500.png 500w, https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/65bfcb8f7e4ae2e81db4070d_image-removebg-preview.png 510w"
        class="image-3" />
    <div class="w-form">
    <?php
		if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
    ?>
        <form id="email-form" name="email-form" method="post" class="form form-2" action="UpdateTransport.php" enctype="multipart/form-data"><input
                class="text-field w-input" maxlength="256" name="name" data-name="Name"
                value="<?php echo $row['trans_name']; ?>" type="text" id="name" /><input type="submit"
                data-wait="Please wait..." style="margin-top:200px;" class="submit-button w-button" value="Submit" /><textarea
                maxlength="5000" id="description" name="description" data-name="Field" class="textarea w-input"><?php echo $row['trans_description']; ?></textarea><label
                for="field" class="field-label-2">The Description :</label><label for="name" class="field-label">Name
                :</label><a href="123.php" style="margin-top:200px;" class="button-2 w-button">Back</a>
            <div class="text-block-5">Photo :</div>
		<input type="file" style="width:350px;" value="<?php echo $row['tra_img']; ?>" class="button-3 w-button" name="image" required/>
		<img src="<?php echo $row['tra_img']; ?>" loading="lazy" width="100" sizes="100px" alt="" class="image-4" />
		<input
                class="text-field w-input" style="margin-top:375px;" maxlength="256" name="link" placeholder="" type="text"
                id="link" value="<?php echo $row['trans_link']; ?>" />
		    <label for=""
                class="field-label-2" style="margin-top:250px;">link :</label>
		<input type="number" name="id" value="<?php echo $row['trans_num']; ?>" hidden />
        </form>
	<?php } } ?>
        <div class="w-form-done">
            <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
            <div>Oops! Something went wrong while submitting the form.</div>
        </div>
    </div>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65bfa2e25894473eed6c3a62"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65bfa2e25894473eed6c3a62/js/webflow.7bedb1dbc.js"
        type="text/javascript"></script>
</body>

</html>