<?php
// Define database connection information
        $servername = "localhost"; // Server name
        $username = "root"; // Username
        $password = ""; // Password, left empty here
        $database = "tourist_road"; // Name of the database to connect to

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $database);

        // Check if the connection is successful
        if ($conn->connect_error) {
            // If the connection fails, display the error message and exit the program
            die("Connection failed: " . $conn->connect_error);
        }
session_start();
if(isset($_SESSION["email"])){
	$email=$_SESSION["email"];
}
if (isset($_POST['Password']) and isset($_POST['ConfirmPassword']) and isset($_POST['FirstName']) and isset($_POST['LastName']))
{
	$email = $_POST['Email'];
	$password = $_POST['Password'];
	$Confirmpassword = $_POST['ConfirmPassword'];
	$firstname=$_POST['FirstName'];
	$lastname=$_POST['LastName'];
	if($password==$Confirmpassword){
	$sql = "INSERT INTO `visitor`(`ID`, `first_name`, `last_name`, `Email`, `password`) 
		VALUES (NULL,'$firstname','$lastname`','$email','$password')";
		if(mysqli_query($conn, $sql)){
			echo "<script>window.location.href = 'homepage1.php?Email=".$email."'</script>";
		}
		else{
			echo "<script>alert('Invalid Sign Up!');";
			echo "window.location.href = 'Register.php'</script>";
		}
	}
	else{
		echo "<script>alert('password and confirm password not match!');";
		echo "window.location.href = 'Register.php'</script>";
	}	
}
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 07:40:19 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="sign-up-e28130.webflow.io" data-wf-page="65bfc49267c2d3e3645a8363"
    data-wf-site="65bfc49267c2d3e3645a8342">

<head>
    <meta charset="utf-8" />
    <title>sign up</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65bfc49267c2d3e3645a8342/css/sign-up-e28130.webflow.1b9eccf1f.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=UT0EgVuLO4MWHy2A0tUs7B4dVkvMKZlSGa0UcLd6dm9zk36KA5Wgg-YBlmw3_MC0ilGa292Vrae8nFDZHqlc3g"
        charset="UTF-8"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Merriweather:300,300italic,400,400italic,700,700italic,900,900italic", "PT Serif:400,400italic,700,700italic", "Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65bfc49267c2d3e3645a8342/65cb0744c2724ff858ef8539_ee.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/65bfc49267c2d3e3645a8342/65cb07495e885518701717de_eee.jpg"
        rel="apple-touch-icon" />
</head>

<body class="body">
    <div class="nav-menu-three-2-copy">
        <ul role="list" class="nav-menu-block-2 w-list-unstyled">
            <li><a href="#" class="nav-link-3">Home</a></li>
            <li><a href="#" class="nav-link-3">Cities</a><a href="#" class="nav-link-3">Help</a></li>
            <li>
                <div data-hover="false" data-delay="0" class="nav-dropdown-2 w-dropdown">
                    <div class="nav-dropdown-toggle-2 w-dropdown-toggle"></div>
                    <nav class="nav-dropdown-list-2 shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 1</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 2</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 3</a></nav>
                </div>
            </li>
        </ul><img
            src="https://assets-global.website-files.com/65bfc49267c2d3e3645a8342/65bfc8dcad4984d075aaeeff_image.png"
            loading="lazy" width="123" alt="" class="image-4" />
        <form action="/search" class="search w-form"><input class="search-input w-input" maxlength="256" name="query"
                placeholder="Search…" type="search" id="search" required="" /><input type="submit"
                class="search-button w-button" value="Search" /></form>
    </div>
    <h3 class="heading">Sign up to Tourist Road</h3>
    <div class="form-block-2 w-form">
        <form id="email-form" name="email-form" class="form-5" data-name="Email Form" method="post" action="Register.php"><label
                for="Name">First Name</label><input class="text-field-4 w-input" maxlength="256" name="FirstName"
                placeholder="e.g. William" type="text" id="FirstName" required /><label
                for="Name-2">Last Name</label><input class="text-field-5 w-input" maxlength="256" name="LastName"
                placeholder="e.g. Christopher" type="text" id="LastName" required /><label
                for="Email-2">Email Address</label><input class="text-field-6 w-input" maxlength="256" name="Email" 
                placeholder="e.g. tr@gmail.com"  type="email" id="Email" pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" value="<?php echo $email; ?> " /><label
                for="Password-3">Password</label><input class="text-field-7 w-input" maxlength="256" name="Password"
                placeholder="* * * * * * * * * * *" type="password" id="Password-3" pattern=".{8,}" title="Eight or more characters"
                required /><label for="Password-4">Confirm Password</label><input class="text-field-8 w-input"
                maxlength="256" name="ConfirmPassword" placeholder="* * * * * * * * * * *"
                type="password" id="ConfirmPassword" required /><input type="submit" data-wait="Please wait..."
                class="submit-button-4 w-button" value="SIGN UP" /></form>
        <div class="w-form-done">
            <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
            <div>Oops! Something went wrong while submitting the form.</div>
        </div>
    </div><a href="https://login-6ce45c.webflow.io/" target="_blank" class="link"><span class="text-span">Have an
            account?</span> <strong>Login</strong></a>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65bfc49267c2d3e3645a8342"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65bfc49267c2d3e3645a8342/js/webflow.3053fd9a1.js"
        type="text/javascript"></script>
</body>

</html>