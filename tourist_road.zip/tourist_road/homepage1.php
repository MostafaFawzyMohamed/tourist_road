<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$query = "SELECT * FROM `city`";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect));
	session_start();
	 
?>
<!DOCTYPE html><!-- This site was created in Webflow. https://www.webflow.com -->
<!-- Last Published: Tue Feb 20 2024 11:41:19 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="home-e45582.webflow.io" data-wf-page="65c124e751aafe14bce63143"
    data-wf-site="65c124e751aafe14bce6313d">

<head>
    <meta charset="utf-8" />
    <title>Home</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65c124e751aafe14bce6313d/css/home-e45582.webflow.abd85d8f1.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=rszujq1gZ6vhTmS-mho_AIjzA_P9OIkQOW8ff7UnjTSsCBOFqFdL3xiAvZ5_aEPwJfvX076cqh2g91lXpmCqgFnjyrhiysCJx43fpTbYVWPi0aTsQeyyziF2TwRfKT0_vp2bXmWYpicKyHBNxAsJ23KsfuRr35AyvDTu_uS7zaYnhktrp9ztiyFS3uDBG6Zy-LKtd8NML7a_QEfg72-1fuB60hJwra2YfcpIaw4uUHW9g1tane2GQm0_mT5v9ueRyMYpsBdufVZHNfSUxrwIrHOOVtayRfL8Hh9T1xtEBlzHymAe8cE8emdNVcBVR6K7AWxjLKVU13M_j2ch-Ipn4u6v6yzQw0Dt2ANOipmjER6i6iUlZNo712MpL4yDC2P1EzR4DXnZH7XTRGIHnsx1gTCyNGQ1X6PxPBajz0Ys3hLar33OMv0mORUc4Ou8nXrKMpWpN-nAKYw8dcpwMoqhPQChcBRHHxz6Wj5x5298ZYIMGcd6H-dc9C36HTjd0kXebblIOvibE6T0HxVVXRGF1bb6r-KhY7o1fhwIRi35_GRBx9aEhZncn9wfSdesPhbsiOeFYPwFFoQZoO7hI39IUBHwikIqd-QhXd2DciF55UyLp1CCHKnIL0wtApqWXK1n1SWemEvixgtZ7RHWvX5eXdwl2gwQ4qKwfVhgUAa0FHIziCFyB6mYEWVI4JGo8mPP6Lou19fbKvPnMdoIgGd3_F9RVtRbjqQ2zkMlPgd9JjzuyWvUQQAaLccHXQDqaqaFQ7s7UHbE9Wkn0FHj3ne1zY2SwYxaoeLQ_NHeVTPnsgRmotH_HdRorRrMDReQGzelCjWds9odCFAN_sumTxknHzvL1sp6RBehS_aVVGiN6GYh2XVyDFwVshW8fQmUZntDHzUcZKB8W5LYAu1p44ZssFR1fZFDFimKlaDt6WP7aoNN4UzoqizutVuhqYxZRspYAQxkvrCvBA0TUNnE2_G1rYBxI_EuwPTnVeVgdAAybk_gxZF0fVB3_hu21JkQXIzUR5ho8-G8WH_jx345UtKkAFseasg8hRayUGyB0FunBf5EEZkNlqME-FuKZQvTuIbRjTG58v1pWZDq18meEqx45gH0wn_vLYS0Cf7uHk18tglAPe4TY8WcHFKuM26pIu3VEpjXCVpGLAlf5M3PBPjGT-i2pgBkW8cX0QxC9qXkk4n-S-FY9wXLw65HsbxY6Ed0C_Imeik9rcVcmtB8B8O6xeCi0mHQmIJUXY1-VDwXZG3Mn3-dTDqAS8VkK58WPJLlHKbSUsUQg1WlSk5mh0PczksZGQ9dc6RuzCLjVNZUv4jqv81u1FLYLybnpi1pw8E9poVL8Z7W38-MhVJnWUmQOY21yf_6wuwdtcXmG17uSkEJ_IkGU8qOYaCAG9fGqHSAkpdA8BppeMRoPGz_Cz0v3u9WQjxxi3BJrWGpf78A2mr8A4ApcYAnqYitOC1fj6tT5vWfruupUpFyFgpTa7oRUW6PT2yhtXPQTTDXZfnwgjWP5PbZcl4EwRTNNTD0SrhxlNlKGrMAJ6UofLZUGI34CO8Se7AkLIcxiUvol_y5IRBdK-ooO9pNNKnYIMQI05isxjX6UYv4VXSmF_LEaSo61rRgUxx8a22XT82_sVGWDvPrYz9GuGz0Tszx9zjzmNY3" nonce="5ead1d92a9a42cbe53f46a8c6caa91e0" charset="UTF-8"></script><script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Droid Serif:400,400italic,700,700italic"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link
        href="https://assets-global.website-files.com/65c124e751aafe14bce6313d/65cade76b02e35e5327c8101_Black%20Elegant%20Modern%20Name%20Initials%20Monogram%20Logo%20(1).jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link
        href="https://assets-global.website-files.com/65c124e751aafe14bce6313d/65cadea294aabf2044a313e5_Black%20Elegant%20Modern%20Name%20Initials%20Monogram%20Logo%20(2).jpg"
        rel="apple-touch-icon" />
</head>

<body class="body-2">
    <section class="section-6"><img
            src="https://assets-global.website-files.com/65c124e751aafe14bce6313d/65c12e6bf152c8903765a9d4_image%20(2)%20(1).png"
            loading="lazy" width="181" id="w-node-_15311489-8497-e68f-8bbe-663b8139f3ad-bce63143" alt=""
            srcset="https://assets-global.website-files.com/65c124e751aafe14bce6313d/65c12e6bf152c8903765a9d4_image%20(2)%20(1)-p-500.png 500w, https://assets-global.website-files.com/65c124e751aafe14bce6313d/65c12e6bf152c8903765a9d4_image%20(2)%20(1).png 561w"
            sizes="(max-width: 1279px) 81.989990234375px, 6vw" class="_22222722" /><a
            id="w-node-_3c401c42-9518-bf71-f08b-da1b8b320d45-bce63143" href="https://home-e45582.webflow.io/"
            class="link-5">Home </a><a id="w-node-a5e6e618-d85b-082d-2652-07fdd97789b9-bce63143" href="/"
            aria-current="page" class="link-9 w--current">Cities</a><a
            id="w-node-a72ab30d-2336-c4e7-a9f9-a5e9ae14bd6e-bce63143" href="https://home-e45582.webflow.io/chat"
            class="link-10"> | Help</a>
        <form action="/search" id="w-node-_40b354cc-50e0-28c2-c1d5-991c306dede7-bce63143" class="search-4 w-form"><input
                class="search-input-2 w-input" maxlength="256" name="query" placeholder="Search…" type="search"
                id="search" required="" /></form>
		<?php 
			if(isset($_SESSION["email"]) && $_SESSION["email"]!=""){
		?>
			<a id="w-node-_3db641fa-69eb-9f54-46a6-ee161728779d-bce63143"
            href="UpdateProfile.php" class="button-12 w-button" style="width:250px;"><?php echo $_SESSION["email"]; ?></a>
		<?php
			}
			else{
				

		?>
		<a id="w-node-_3db641fa-69eb-9f54-46a6-ee161728779d-bce63143"
            href="Login.php" class="button-12 w-button">Login</a><a
            id="w-node-fce6bcaf-d06b-4790-fbc2-d37e84175643-bce63143" href="CreateAccount.php"
            class="button-11 w-button">Sign Up</a>
		<?php } ?>
    </section>
    <section class="section-8">
        <div id="w-node-a2b87488-8d50-9200-5670-3d29e9254526-bce63143" class="text-block">A website (Tourist&#x27;s
            road) facilitates the tourist&#x27;s access to many hotels, restaurants, cafes, farms and tourist
            destinations in one website ...</div><img
            src="https://assets-global.website-files.com/65c124e751aafe14bce6313d/65c12e6bf152c8903765a9d4_image%20(2)%20(1).png"
            loading="lazy" width="189" id="w-node-_1a6c81b9-f2f7-8d6c-9b0f-2a1784eddbdb-bce63143" alt=""
            srcset="https://assets-global.website-files.com/65c124e751aafe14bce6313d/65c12e6bf152c8903765a9d4_image%20(2)%20(1)-p-500.png 500w, https://assets-global.website-files.com/65c124e751aafe14bce6313d/65c12e6bf152c8903765a9d4_image%20(2)%20(1).png 561w"
            sizes="(max-width: 479px) 56vw, (max-width: 767px) 29vw, 188.99998474121094px" class="image-1427" />
    </section>
    <?php 
     if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
	?>	
    <section class="section-581"><a href="ServicesList.php?city_id=<?php echo $row['city_id']; ?>"><img
            src="<?php echo $row['city_img']; ?>"
            width="500" alt=""
            class="image-3" /></a><a href="ServicesList.php?city_id=<?php echo $row['city_id']; ?>" style="text-align:center; height:500px; width:800px;" class="button-4 w-button"><strong><p style="font-size:25px;"><?php echo $row['city_name']; ?></p></strong><p style="font-size:20px; "><?php echo $row['city_description']; ?></p></a>
     </section>
     <?php 
     } } ?>
    
    <section class="section-7"></section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c124e751aafe14bce6313d"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c124e751aafe14bce6313d/js/webflow.99dcd72d4.js"
        type="text/javascript"></script>
</body>

</html>