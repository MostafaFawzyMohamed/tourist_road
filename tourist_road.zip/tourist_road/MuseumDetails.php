<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$mus_num=$_GET['mus_num'];
	$query = "SELECT * FROM `museum` WHERE mus_num='$mus_num'";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect)); 
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 16:16:28 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="torist-road-5fed55.webflow.io" data-wf-page="65c1155fefcfe8e41cf315ad"
    data-wf-site="65c1155fefcfe8e41cf315a6">

<head>
    <meta charset="utf-8" />
    <title>Museum Details</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65c1155fefcfe8e41cf315a6/css/torist-road-5fed55.webflow.925509077.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=HAkQGU4jpAWx8RVL0phAD40b4Kg4AF0UPVMuqBgYxIK4e58tLdbYL_csKd1sLz8PXyCn0ImTm1qcaRCYx7suqQ"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65c1155fefcfe8e41cf315a6/65d4cfce3f4245b4e6828e85_lil.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body class="body">
    <div class="nav-menu-three-2-copy">
        <ul role="list" class="nav-menu-block-2 w-list-unstyled">
            <li><a href="#" class="nav-link-3">Home</a></li>
            <li><a href="#" class="nav-link-3">Cities</a><a href="#" class="nav-link-3">Help</a></li>
            <li>
                <div data-hover="false" data-delay="0" class="nav-dropdown-2 w-dropdown">
                    <div class="nav-dropdown-toggle-2 w-dropdown-toggle"></div>
                    <nav class="nav-dropdown-list-2 shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 1</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 2</a><a href="#"
                            class="nav-dropdown-link-2 w-dropdown-link">Resource Link 3</a></nav>
                </div>
            </li>
        </ul><img
            src="https://assets-global.website-files.com/65c0e134dd798acb4fad24f2/65c0e2192a01d6fc97451d57_image__1_-removebg-preview.png"
            loading="lazy" width="147" alt="" />
        <form action="/search" class="w-form"><input class="search-input w-input" maxlength="256" name="query"
                placeholder="Search…" type="search" id="search" required="" /><input type="submit"
                class="search-button w-button" value="Search" /><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                loading="lazy" width="49" alt="" class="image" /><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                loading="lazy" width="49" alt="" class="image" /></form>
    </div>
    <section class="hero-heading-right">
        <div class="container">
		<?php 
			     if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
		?>
            <div class="hero-wrapper">
                <div class="hero-split"><img
                        src="<?php echo $row['mus_img']; ?>"
                        loading="lazy" sizes="(max-width: 479px) 88vw, 300px"
                        srcset="<?php echo $row['mus_img']; ?> 500w"
                        alt="" class="shadow-two" /></div>
                <div class="hero-split">
                    <h1 class="heading"><strong><?php echo $row['mus_name']; ?></strong>.</h1>
                    <p class="margin-bottom-24px"> <?php echo $row['mus_description']; ?></p>
                </div>
            </div>
	
        </div><a href="Museums.php" class="button-primary w-button">Back</a><img
            src="https://assets-global.website-files.com/65c1155fefcfe8e41cf315a6/65c1f7279899b6ff2d98d149_%D9%85%D9%81%D8%B6%D9%84%D9%872.jpg"
            loading="lazy" width="34" sizes="34px" alt=""
            srcset="https://assets-global.website-files.com/65c1155fefcfe8e41cf315a6/65c1f7279899b6ff2d98d149_%D9%85%D9%81%D8%B6%D9%84%D9%872-p-500.jpg 500w, https://assets-global.website-files.com/65c1155fefcfe8e41cf315a6/65c1f7279899b6ff2d98d149_%D9%85%D9%81%D8%B6%D9%84%D9%872.jpg 640w"
            class="image-2" /><a id="https-maps.app.goo.gl-yM7zkpY57mp9w8Lh6-g_st-ic"
            href="<?php echo $row['mus_link']; ?>" class="link">To go to the location click here</a>
    <?php }} ?>
    </section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c1155fefcfe8e41cf315a6"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c1155fefcfe8e41cf315a6/js/webflow.47303a7fd.js"
        type="text/javascript"></script>
</body>

</html>