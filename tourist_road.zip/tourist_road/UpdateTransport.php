<?php
	// Define database connection information
        $servername = "localhost"; // Server name
        $username = "root"; // Username
        $password = ""; // Password, left empty here
        $database = "tourist_road"; // Name of the database to connect to

        // Create a connection to the database
        $conn = new mysqli($servername, $username, $password, $database);

        // Check if the connection is successful
        if ($conn->connect_error) {
            // If the connection fails, display the error message and exit the program
            die("Connection failed: " . $conn->connect_error);
        }

	if(isset($_POST["id"]) and isset($_POST["name"]) and isset ($_POST["description"]))
	{
		$id=$_POST["id"];
		$name=$_POST["name"];
		$description= $_POST["description"];
		$link= $_POST["link"];
		$fileName = $_FILES['image']['name'];
		$fileError = $_FILES['image']['error'];
		$fileType = $_FILES['image']['type'];
		$fileSize = $_FILES['image']['size'];
		$data = file_get_contents($_FILES['image']['tmp_name']);
		$file = $_FILES['image']['tmp_name'];
		$fileExt = explode('.', $fileName);
		$fileActualExt = strtolower(end($fileExt));
		$allowed = array('csv','doc','docx','jpg','pdf','png');
		$destination = 'img/Transport/' . $fileName;
		if (in_array($fileActualExt, $allowed)){
			if ($fileError == 0){
				if ($fileSize < 5000000){
					$sql="UPDATE `transportation` SET `trans_name`='$name',`tra_img`='$destination',
					`trans_description`='$description', `trans_link`='$link' WHERE `trans_num`='" . $id . "'" ;
					if (mysqli_query($conn, $sql)) {
						if (move_uploaded_file($file, $destination)) {
						echo "<script>window.location.href = 'ViewTransportation.php'";
						echo "</script>";
						}
					} else {
						echo "<script>alert('Invalid Update');";
						echo "window.location.href = 'editTransportation.php?transport_id=".$id."'";
						echo "</script>";
					}
					}
			}
		}
	}
	mysqli_close($conn);
?>