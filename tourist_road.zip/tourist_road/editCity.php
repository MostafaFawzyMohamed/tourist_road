<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Mar 12 2024 21:42:13 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="222-15f145.webflow.io" data-wf-page="65c9447e4522ac324b18dde4"
    data-wf-site="65c0055de25c9e1161d160a5">

<head>
    <meta charset="utf-8" />
    <title>Edit city</title>
    <meta content="Edit city" property="og:title" />
    <meta content="Edit city" property="twitter:title" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65c0055de25c9e1161d160a5/css/222-15f145.webflow.c578cf232.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=AEHkerOS0udkCigFEPtJoJ8btE8VfS7N5IQiCsHImTOluCPKcoaXsU15Xm5uhO-epccIvUKx1WPMRcAOQmdmsw"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65c0055de25c9e1161d160a5/65d49bd1ddffc2effbe6b73a_TRRR.png"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body class="body-2">
    <div class="nav-menu-three">
        <ul role="list" class="nav-menu-block w-list-unstyled">
            <li>
                <div data-hover="false" data-delay="0" class="nav-dropdown w-dropdown">
                    <div class="nav-dropdown-toggle w-dropdown-toggle"></div>
                    <nav class="nav-dropdown-list shadow-three mobile-shadow-hide w-dropdown-list"><a href="#"
                            class="nav-dropdown-link w-dropdown-link">Resource Link 1</a><a href="#"
                            class="nav-dropdown-link w-dropdown-link">Resource Link 2</a><a href="#"
                            class="nav-dropdown-link w-dropdown-link">Resource Link 3</a></nav>
                </div>
            </li>
        </ul><img
            src="https://assets-global.website-files.com/65b9686e49248c9a63b1662b/65be638e19d6a084e4867eed_image__7_-removebg-preview.png"
            loading="lazy" width="64" height="50" alt="" class="image-2" /><a href="https://home-e45582.webflow.io/"
            class="button-4 w-button">log out</a><img
            src="https://assets-global.website-files.com/65c0055de25c9e1161d160a5/65c9161cb3fbb4c954ad8b0b_image-removebg-preview.png"
            loading="lazy" width="150" sizes="150px" alt=""
            srcset="https://assets-global.website-files.com/65c0055de25c9e1161d160a5/65c9161cb3fbb4c954ad8b0b_image-removebg-preview-p-500.png 500w, https://assets-global.website-files.com/65c0055de25c9e1161d160a5/65c9161cb3fbb4c954ad8b0b_image-removebg-preview.png 510w"
            class="image-3" /><a href="#" class="link-4">Cities</a><a href="#" class="link-3">Ratings</a>
    </div>
    <div class="w-form">
        <form id="email-form" name="email-form" data-name="Email Form" method="get"
            data-wf-page-id="65c9447e4522ac324b18dde4" data-wf-element-id="9d6faeb4-5bad-921a-586c-1a0c247e3436">
            <div class="text-block-3">Cities</div>
            <div class="text-block-4">Raitings</div>
        </form>
        <div class="w-form-done">
            <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
            <div>Oops! Something went wrong while submitting the form.</div>
        </div>
    </div>
    <h1 class="heading-3">Edit city </h1>
    <div class="w-form">
        <form id="email-form-2" name="email-form-2" data-name="Email Form 2" method="get"
            data-wf-page-id="65c9447e4522ac324b18dde4" data-wf-element-id="b5584d85-4e92-c660-b96f-ca042c30790e"><select
                id="field" name="field" data-name="Field" class="select-field-2 w-select">
                <option value="">Taif</option>
                <option value="First">Abha</option>
                <option value="Second">ALbaha</option>
            </select><label for="field" class="field-label-4">Choose the city </label></form>
        <div class="w-form-done">
            <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
            <div>Oops! Something went wrong while submitting the form.</div>
        </div>
    </div>
    <div class="w-form">
        <form id="email-form-3" name="email-form-3" data-name="Email Form 3" method="get" class="form-2"
            data-wf-page-id="65c9447e4522ac324b18dde4" data-wf-element-id="44a27ef3-911c-3170-633d-b4d124edb52c"><label
                for="name" class="field-label-5">select the menu</label></form>
        <div class="w-form-done">
            <div>Thank you! Your submission has been received!</div>
        </div>
        <div class="w-form-fail">
            <div>Oops! Something went wrong while submitting the form.</div>
        </div>
    </div><a href="ViewTransportation.php" class="button-9 w-button">transportation</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-7 w-button">Restaurants and cafes</a><a href="#"
        class="button-7 w-button">Restaurants and cafes</a><a href="#" class="button-7 w-button">Restaurants and
        cafes</a><a href="#" class="button-7 w-button">Restaurants and cafes</a><a href="#"
        class="button-7 w-button">Restaurants and cafes</a><a href="#" class="button-8 w-button">Hotels</a><a href="#"
        class="button-7 w-button">Restaurants and cafes</a><a href="#" class="button-7 w-button">Restaurants and
        cafes</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#" class="button-6 w-button">Events,
        entertainment and parks</a><a href="#" class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-6 w-button">Events, entertainment and parks</a><a href="#"
        class="button-10 w-button">Museums</a><a href="citySettings.html"
        class="button-11 w-button">Cancel</a>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c0055de25c9e1161d160a5"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c0055de25c9e1161d160a5/js/webflow.7bedb1dbc.js"
        type="text/javascript"></script>
</body>

</html>