<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	$query = "SELECT * FROM `transportation`";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect)); 
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Mar 12 2024 22:08:01 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="wajds-spectacular-site.webflow.io" data-wf-page="65bd255b4a39174f54d36943"
    data-wf-site="65bd255b4a39174f54d36940">

<head>
    <meta charset="utf-8" />
    <title>Transportation</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link
        href="https://assets-global.website-files.com/65bd255b4a39174f54d36940/css/wajds-spectacular-site.webflow.1dc9c99c8.css"
        rel="stylesheet" type="text/css" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=kEuK-RdpWSDodiNrvVEpz4KHyviILJxD32wb3Z-7QonxeyEuPURSukjKdvXTHOv--NaGune6G_XiNk7btA_Rpw"
        charset="UTF-8"></script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link href="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65d345100e1a0d1cf6a04543_logo.jpg"
        rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
</head>

<body>
    <div class="navbar-logo-center">
        <div data-animation="default" data-collapse="medium" data-duration="100" data-easing="ease" data-easing2="ease"
            role="banner" class="navbar-logo-center-container shadow-three w-nav">
            <div class="container-5">
                <div class="navbar-wrapper-three"><a href="#" class="navbar-brand-three w-nav-brand"><img
                            src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be4ac3334196f9c563294f_image-removebg-preview.png"
                            loading="lazy" width="200" height="200" alt=""
                            srcset="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be4ac3334196f9c563294f_image-removebg-preview-p-500.png 500w, https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be4ac3334196f9c563294f_image-removebg-preview.png 510w"
                            sizes="(max-width: 479px) 63vw, 200px" /></a>
                    <nav role="navigation" class="nav-menu-wrapper-three w-nav-menu">
                        <div class="nav-menu-three-2">
                            <ul role="list" class="nav-menu-block w-list-unstyled">
                                <li><a href="https://home-e45582.webflow.io/" class="nav-link-3">Home</a></li>
                                <li><a href="https://home-e45582.webflow.io/" class="nav-link-3">Cities</a><a
                                        href="https://home-e45582.webflow.io/chat" class="nav-link-3">Help</a></li>
                                <li>
                                    <div data-hover="false" data-delay="0" class="nav-dropdown-2 w-dropdown">
                                        <div class="nav-dropdown-toggle-2 w-dropdown-toggle"></div>
                                        <nav
                                            class="nav-dropdown-list-2 shadow-three mobile-shadow-hide w-dropdown-list">
                                            <a href="#" class="nav-dropdown-link-2 w-dropdown-link">Resource Link
                                                1</a><a href="#" class="nav-dropdown-link-2 w-dropdown-link">Resource
                                                Link 2</a><a href="#"
                                                class="nav-dropdown-link-2 w-dropdown-link">Resource Link 3</a></nav>
                                    </div>
                                </li>
                            </ul>
                            <form action="/search" class="search w-form"><input class="search-input w-input"
                                    maxlength="256" name="query" placeholder="Search…" type="search" id="search"
                                    required="" /><input type="submit" class="search-button w-button"
                                    value="Search" /><a href="https://edit-8193cf.webflow.io/favlist"
                                    class="w-inline-block"><img
                                        src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                                        loading="lazy" width="49" alt="" class="image" /></a><a
                                    href="https://edit-8193cf.webflow.io/" class="w-inline-block"><img
                                        src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                                        loading="lazy" width="49" alt="" class="image" /></a></form>
                        </div>
                    </nav>
                    <div class="menu-button-2 w-nav-button">
                        <div class="w-icon-nav-menu"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="hero-heading-left">
        <div class="text-block"><strong class="bold-text" data-ix="new-interaction"> Transportation</strong></div><br>
     <?php 
		if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
	?>
        <div class="container">
            <div class="hero-wrapper">
                <div class="hero-split">
                    <h1 class="heading"><strong><?php echo $row['trans_name']; ?></strong><br /></h1>
                    <p class="margin-bottom-24px"><?php echo $row['trans_description']; ?></p><a
                        href="<?php echo $row['trans_link']; ?>"
                        class="button-primary w-button">CLICK HERE</a>
                </div>
                <div class="hero-split"><img
                        src="<?php echo $row['tra_img']; ?>"
                        loading="lazy"
                        sizes="(max-width: 479px) 94vw, (max-width: 767px) 95vw, (max-width: 991px) 92vw, (max-width: 1279px) 43vw, 432.375px"
                        srcset="<?php echo $row['tra_img']; ?> 500w"
                        alt="" class="shadow-two" /></div>
            </div>
        </div>
	  <br />
	<center><hr style="width:900px;"></center>
	<br />
    <?php } } ?>
    </section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65bd255b4a39174f54d36940"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/js/webflow.2b7b0b021.js"
        type="text/javascript"></script>
</body>

</html>