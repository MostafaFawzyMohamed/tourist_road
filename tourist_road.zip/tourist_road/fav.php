<?php
	$connect = mysqli_connect("localhost", "root", "","tourist_road");
	if(isset($_GET['email']))
		$email=$_GET['email'];
	$visitor_id=0;
	$sql = "SELECT ID FROM `visitor` WHERE Email='$email'";
	$find = mysqli_query($connect, $sql);
	if ($find->num_rows > 0) {
	// output data of each row
		while($visitor = $find->fetch_assoc()) {
			$visitor_id=$visitor['ID'];
		}
	}
	$query = "SELECT * FROM `favorites` WHERE visitor_id='$visitor_id'";
	$result = mysqli_query($connect, $query) or die(mysqli_error($connect)); 
?>
<!DOCTYPE html>
<!-- This site was created in Webflow. https://www.webflow.com --><!-- Last Published: Tue Feb 20 2024 11:44:55 GMT+0000 (Coordinated Universal Time) -->
<html data-wf-domain="edit-8193cf.webflow.io" data-wf-page="65c91c05aeab9fdc6460cf28"
    data-wf-site="65c168b02366ea90a1a0c745">

<head>
    <meta charset="utf-8" />
    <title>FavList</title>
    <meta content="FavList" property="og:title" />
    <meta content="FavList" property="twitter:title" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />
    <link href="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/css/edit-8193cf.webflow.7f0c794ef.css"
        rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script type="text/javascript"
        src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=UBscHQZjQ90NXbz3wNtBdmCWAcI5Ca1m8COGeGSgWXVkpbwsoXmSptUyxULzWWWsf_6ug2tQ4YYziHEeu-xZvQ"
        charset="UTF-8"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script
        type="text/javascript">WebFont.load({ google: { families: ["Droid Serif:400,400italic,700,700italic", "Lato:100,100italic,300,300italic,400,400italic,700,700italic,900,900italic"] } });</script>
    <script
        type="text/javascript">!function (o, c) { var n = c.documentElement, t = " w-mod-"; n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch") }(window, document);</script>
    <link
        href="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65cacdb35738ea91b2e3169d_%D8%B5%D9%88%D8%B1%D9%87%20%D8%A7%D9%84%D8%B4%D8%B9%D8%A7%D8%B1%20(2)%20(2).png"
        rel="shortcut icon" type="image/x-icon" />
    <link
        href="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65cacd68db06007b72c8c9b7_%D8%B5%D9%88%D8%B1%D9%87%20%D8%A7%D9%84%D8%B4%D8%B9%D8%A7%D8%B1%20(2)%20(1).png"
        rel="apple-touch-icon" />
</head>

<body class="body-2">
    <section class="sec22"><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c168d4513acc4c96746f43_image%20(2)%20(1).png"
            loading="lazy" width="174" id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd688-6460cf28" alt=""
            srcset="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c168d4513acc4c96746f43_image%2520(2)%2520(1)-p-500.png 500w, https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c168d4513acc4c96746f43_image%20(2)%20(1).png 561w"
            sizes="173.99998474121094px" class="image-2" />
        <form action="/search" class="search-2 w-form"><input class="search-input-2 w-input" maxlength="256"
                name="query" placeholder="Search…" type="search" id="search" required="" /></form><a
            id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd68c-6460cf28" href="/" class="w-inline-block"><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be502fe9f7d9a74b7eb32b_image__7_-removebg-preview.png"
                loading="lazy" width="36" id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd68d-6460cf28" alt=""
                class="account-button" /></a><a id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd699-6460cf28" href="#"
            class="link"> | Help</a><a id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd69b-6460cf28"
            href="https://home-e45582.webflow.io/" class="link-3">Home |</a><a
            id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd69d-6460cf28" href="https://home-e45582.webflow.io/"
            class="link-2">Cities</a><a id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd69f-6460cf28" href="/favlist"
            aria-current="page" class="w-inline-block w--current"><img
                src="https://assets-global.website-files.com/65bd255b4a39174f54d36940/65be50c570efe705e806b31a_pngtree-vector-favourite-icon-png-image_855001-removebg-preview.png"
                alt="" width="36" id="w-node-_33c01861-183e-7d3b-1fb1-9c9eb7cdd6a0-6460cf28" class="image-11" /></a>
    </section>
    <main class="sec44"><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c16ecf3a33777ac3cfdae3_11111111111%20(1).png"
            loading="lazy" width="181" alt="" class="image-144" /><a href="UpdateProfile.php?email=<?php echo $email; ?>"
            class="editaccountbutton w-button">Edit account</a><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c16ecf67474f9922240d64_222222222222.png"
            loading="lazy" width="173" alt="" class="image-133" /><a href="fav.php?email=<?php echo $email; ?>"
            class="favoritebutton w-button">Favorite</a><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65c16ece1c36dbf932a38a68_33333333333333.png"
            loading="lazy" width="166" alt="" class="image-155" /><a href="Notifications.php?email=<?php echo $email; ?>"
            class="notificationsbutton w-button">Notifications</a></main>
    <section class="section-8">
        <h1 class="heading-3">Your Favorite</h1>
    </section>
    <section></section>
     <?php 
			     if ($result->num_rows > 0) {
					// output data of each row
					while($row = $result->fetch_assoc()) {
		?>
    <img
        src="<?php echo $row['fav_img']; ?>"
        loading="lazy" width="444" sizes="(max-width: 479px) 100vw, 443.9999694824219px" alt=""
        srcset="<?php echo $row['fav_img']; ?> 500w"
        class="image-156" />
	 
    <section class="section-10">
        <h1 class="heading-4"><?php echo $row['fav_name']; ?></h1>
        <p class="paragraph-4"><?php echo $row['fav_description']; ?></p><a href="#" class="link-4">Move to the café location</a><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65d2ffed32f7c1139afa5220_60993.png"
            loading="lazy" width="35" alt="" class="image-157" /><img
            src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/65d30d58c785c88d1c0d54ef_%D9%84%D9%82%D8%B7%D8%A9%20%D8%B4%D8%A7%D8%B4%D8%A9%202024-02-19%20110531.png"
            loading="lazy" width="143" alt="" class="image-160" />
    </section>
	<?php } } ?>
    <section></section>
    <section class="section-11"></section>
    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=65c168b02366ea90a1a0c745"
        type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
        crossorigin="anonymous"></script>
    <script src="https://assets-global.website-files.com/65c168b02366ea90a1a0c745/js/webflow.4e708f6a0.js"
        type="text/javascript"></script>
</body>

</html>